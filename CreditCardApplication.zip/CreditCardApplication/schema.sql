-- ============================================================
-- Credit Card Management System - MySQL Schema
-- Run this file in MySQL Workbench before starting the app
-- ============================================================

CREATE DATABASE IF NOT EXISTS credit_card_db;
USE credit_card_db;

-- -----------------------------------------------
-- Table: users
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id     INT          AUTO_INCREMENT PRIMARY KEY,
    user_name   VARCHAR(50)  NOT NULL UNIQUE,
    password    VARCHAR(64)  NOT NULL,          -- MD5 hashed
    email       VARCHAR(100) NOT NULL UNIQUE,
    phone_no    VARCHAR(15)  NOT NULL,
    role        ENUM('ADMIN','CUSTOMER') NOT NULL DEFAULT 'CUSTOMER',
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- -----------------------------------------------
-- Table: credit_cards
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS credit_cards (
    card_id           INT           AUTO_INCREMENT PRIMARY KEY,
    card_number       VARCHAR(19)   NOT NULL UNIQUE,   -- format: XXXX-XXXX-XXXX-XXXX
    user_id           INT           NOT NULL,
    credit_limit      DECIMAL(12,2) NOT NULL DEFAULT 50000.00,
    available_balance DECIMAL(12,2) NOT NULL DEFAULT 50000.00,
    status            ENUM('PENDING','ACTIVE','BLOCKED','EXPIRED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    expiry_date       DATE          NOT NULL,
    pin               VARCHAR(64)   DEFAULT NULL,      -- MD5 hashed 4-digit PIN
    cvv               VARCHAR(3)    NOT NULL,
    card_type         VARCHAR(20)   NOT NULL DEFAULT 'VISA',
    applied_at        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- -----------------------------------------------
-- Table: transactions
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS transactions (
    txn_id      INT           AUTO_INCREMENT PRIMARY KEY,
    card_id     INT           NOT NULL,
    amount      DECIMAL(12,2) NOT NULL,
    txn_type    ENUM('PURCHASE','CASH_ADVANCE','PAYMENT','REFUND') NOT NULL,
    description VARCHAR(255)  DEFAULT '',
    txn_date    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (card_id) REFERENCES credit_cards(card_id) ON DELETE CASCADE
);

-- -----------------------------------------------
-- Table: bills
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS bills (
    bill_id       INT           AUTO_INCREMENT PRIMARY KEY,
    card_id       INT           NOT NULL,
    bill_month    VARCHAR(7)    NOT NULL,            -- format: YYYY-MM
    total_amount  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    minimum_due   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    due_date      DATE          NOT NULL,
    is_paid       TINYINT(1)    NOT NULL DEFAULT 0,
    paid_amount   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (card_id) REFERENCES credit_cards(card_id) ON DELETE CASCADE
);

-- -----------------------------------------------
-- Seed Data: Default Admin User
-- Username: admin  |  Password: admin123  (MD5 hashed)
-- -----------------------------------------------
INSERT IGNORE INTO users (user_name, password, email, phone_no, role)
VALUES ('admin', MD5('admin123'), 'admin@creditcard.com', '9999999999', 'ADMIN');
