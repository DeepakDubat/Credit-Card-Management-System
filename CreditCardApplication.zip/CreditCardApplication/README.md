# Credit Card Management System

## Tech Stack
- **Language:** Java SE 11+
- **Database:** MySQL
- **IDE:** Apache NetBeans
- **Connectivity:** JDBC (MySQL Connector/J)

---

## Project Structure

```
Credit card management system/
├── schema.sql                  ← Run this in MySQL Workbench FIRST
├── build_and_run.bat           ← Alt: compile & run from command line
├── lib/
│   └── mysql-connector-j.jar  ← Download and place here
└── src/
    ├── models/
    │   ├── User.java
    │   ├── CreditCard.java
    │   ├── Transaction.java
    │   └── Bill.java
    ├── dao/
    │   ├── DBConnection.java   ← UPDATE password here
    │   ├── UserDAO.java
    │   ├── CreditCardDAO.java
    │   ├── TransactionDAO.java
    │   └── BillDAO.java
    ├── services/
    │   ├── UserService.java
    │   ├── CardService.java
    │   ├── TransactionService.java
    │   ├── BillingService.java
    │   ├── SecurityService.java
    │   └── ReportService.java
    └── ui/
        ├── Main.java           ← Entry point (Main class)
        ├── AdminMenu.java
        └── CustomerMenu.java
```

---

## Setup Instructions

### Step 1 — Setup MySQL Database
1. Open **MySQL Workbench**
2. Connect to your local MySQL server
3. Open `schema.sql` → Run it (⚡ or Ctrl+Shift+Enter)
4. This creates database `credit_card_db` and tables + admin user

### Step 2 — Download MySQL JDBC Connector
1. Go to: https://dev.mysql.com/downloads/connector/j/
2. Download **Platform Independent** ZIP
3. Extract and copy `mysql-connector-j-x.x.x.jar`
4. Paste it into the `lib/` folder of this project

### Step 3 — Configure Database Password
Open `src/dao/DBConnection.java` and update:
```java
private static final String DB_PASSWORD = "root"; // ← change to your password
```

### Step 4 — Setup in Apache NetBeans
1. Open NetBeans → **File → New Project → Java with Existing Sources**
2. Set **Project Folder** to this directory
3. Add `src/` as the **Source Package Folder**
4. Right-click Project → **Properties → Libraries → Add JAR/Folder**
5. Browse to `lib/mysql-connector-j.jar` → Add it
6. Set **Main Class** to `ui.Main`
7. Press **F6** to Run

---

## Default Login Credentials

| Role  | Username | Password |
|-------|----------|----------|
| Admin | `admin`  | `admin123` |

---

## Features

| Module | Functions |
|--------|-----------|
| User Management | Register, Login, Update Profile, Change Password, Delete Account |
| Card Management | Apply, Issue (Admin), Block, Unblock, Credit Limit Update |
| Transactions | Purchase, Cash Advance (3% fee), Payment, Refund, History |
| Billing | Generate Bill, Pay Bill, Convert to EMI (1.5%/month) |
| Security | Set PIN, OTP Generation, Lock/Unlock Card |
| Reports | Monthly Summary, Spending Analysis, Admin Dashboard |
z