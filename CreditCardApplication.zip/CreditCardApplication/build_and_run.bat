@echo off
echo ==========================================
echo  Credit Card Management System - Build
echo ==========================================

REM ─── Configuration ───────────────────────────────────
set JDBC_JAR=lib\mysql-connector-j.jar
set SRC_DIR=src
set BIN_DIR=bin
set MAIN_CLASS=ui.swing.MainApplication
REM ─────────────────────────────────────────────────────

REM Check if JDBC jar exists
if not exist "%JDBC_JAR%" (
    echo ERROR: MySQL JDBC JAR not found at %JDBC_JAR%
    echo Please download mysql-connector-j.jar and place it in the 'lib' folder.
    echo Download from: https://dev.mysql.com/downloads/connector/j/
    pause
    exit /b 1
)

REM Create bin directory
if not exist "%BIN_DIR%" mkdir "%BIN_DIR%"

echo.
echo [1] Compiling Java source files...
javac -cp "%JDBC_JAR%" -d "%BIN_DIR%" ^
    %SRC_DIR%\models\User.java ^
    %SRC_DIR%\models\CreditCard.java ^
    %SRC_DIR%\models\Transaction.java ^
    %SRC_DIR%\models\Bill.java ^
    %SRC_DIR%\dao\DBConnection.java ^
    %SRC_DIR%\dao\UserDAO.java ^
    %SRC_DIR%\dao\CreditCardDAO.java ^
    %SRC_DIR%\dao\TransactionDAO.java ^
    %SRC_DIR%\dao\BillDAO.java ^
    %SRC_DIR%\services\UserService.java ^
    %SRC_DIR%\services\CardService.java ^
    %SRC_DIR%\services\TransactionService.java ^
    %SRC_DIR%\services\BillingService.java ^
    %SRC_DIR%\services\SecurityService.java ^
    %SRC_DIR%\services\ReportService.java ^
    %SRC_DIR%\ui\swing\MainApplication.java ^
    %SRC_DIR%\ui\swing\LoginFrame.java ^
    %SRC_DIR%\ui\swing\AdminDashboardFrame.java ^
    %SRC_DIR%\ui\swing\CustomerDashboardFrame.java

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Compilation failed! Check the errors above.
    pause
    exit /b 1
)

echo [✓] Compilation successful!
echo.
echo [2] Running the application...
echo ==========================================
java -cp "%BIN_DIR%;%JDBC_JAR%" %MAIN_CLASS%

pause
