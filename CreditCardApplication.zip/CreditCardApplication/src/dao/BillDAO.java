package dao;

import models.Bill;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    private Connection conn;

    public BillDAO() {
        this.conn = DBConnection.getConnection();
    }

    // ── Helper: map ResultSet row → Bill object ──────────────────
    private Bill mapRow(ResultSet rs) throws SQLException {
        return new Bill(
            rs.getInt("bill_id"),
            rs.getInt("card_id"),
            rs.getString("bill_month"),
            rs.getBigDecimal("total_amount"),
            rs.getBigDecimal("minimum_due"),
            rs.getDate("due_date"),
            rs.getBoolean("is_paid"),
            rs.getBigDecimal("paid_amount"),
            rs.getTimestamp("created_at")
        );
    }

    // ────────────────────────────────────────────────────────────
    // generateBill — create a bill for a given card + month.
    // totalAmount = sum of PURCHASE + CASH_ADVANCE in that month.
    // minimumDue  = 5% of totalAmount (minimum Rs. 200).
    // dueDate     = last day of next month.
    // ────────────────────────────────────────────────────────────
    public boolean generateBill(int cardId, String billMonth) {
        // Check if bill already exists for this card + month
        if (billExists(cardId, billMonth)) {
            System.out.println("  [!] Bill already exists for " + billMonth);
            return false;
        }

        // Calculate total from transactions
        TransactionDAO txnDAO = new TransactionDAO();
        BigDecimal total = txnDAO.getTotalSpendingByMonth(cardId, billMonth);

        if (total.compareTo(BigDecimal.ZERO) == 0) {
            System.out.println("  [!] No transactions found for " + billMonth);
            return false;
        }

        // Minimum due = max(5% of total, 200)
        BigDecimal minDue = total.multiply(new BigDecimal("0.05"));
        if (minDue.compareTo(new BigDecimal("200")) < 0) {
            minDue = new BigDecimal("200");
        }

        // Due date: last day of the NEXT month
        java.time.YearMonth ym = java.time.YearMonth.parse(billMonth);
        java.time.LocalDate dueLocalDate = ym.plusMonths(1).atEndOfMonth();
        java.sql.Date dueDate = java.sql.Date.valueOf(dueLocalDate);

        String sql = "INSERT INTO bills (card_id, bill_month, total_amount, minimum_due, due_date) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setString(2, billMonth);
            ps.setBigDecimal(3, total);
            ps.setBigDecimal(4, minDue);
            ps.setDate(5, dueDate);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BillDAO] generateBill error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // makePayment — pay full or partial bill amount
    // ────────────────────────────────────────────────────────────
    public boolean makePayment(int billId, BigDecimal paymentAmount) {
        Bill bill = getBillById(billId);
        if (bill == null) return false;

        BigDecimal remaining = bill.getTotalAmount().subtract(bill.getPaidAmount());
        if (paymentAmount.compareTo(remaining) > 0) {
            paymentAmount = remaining; // cap to outstanding amount
        }

        BigDecimal newPaid = bill.getPaidAmount().add(paymentAmount);
        boolean fullyPaid  = newPaid.compareTo(bill.getTotalAmount()) >= 0;

        String sql = "UPDATE bills SET paid_amount = ?, is_paid = ? WHERE bill_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, newPaid);
            ps.setBoolean(2, fullyPaid);
            ps.setInt(3, billId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BillDAO] makePayment error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // getStatementByCard — all bills for a card
    // ────────────────────────────────────────────────────────────
    public List<Bill> getStatementByCard(int cardId) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills WHERE card_id = ? ORDER BY bill_month DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[BillDAO] getStatementByCard error: " + e.getMessage());
        }
        return list;
    }

    // ── Get single bill by ID ───────────────────────────────────
    public Bill getBillById(int billId) {
        String sql = "SELECT * FROM bills WHERE bill_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, billId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[BillDAO] getBillById error: " + e.getMessage());
        }
        return null;
    }

    // ── Check if bill already generated for a card+month ────────
    public boolean billExists(int cardId, String billMonth) {
        String sql = "SELECT bill_id FROM bills WHERE card_id = ? AND bill_month = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setString(2, billMonth);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            return false;
        }
    }

    // ── Get all unpaid bills (Admin) ────────────────────────────
    public List<Bill> getAllUnpaidBills() {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills WHERE is_paid = 0 ORDER BY due_date";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[BillDAO] getAllUnpaidBills error: " + e.getMessage());
        }
        return list;
    }

    // ── Convert to EMI — splits bill into monthly installments ───
    // Creates EMI records as separate bill entries for each month
    public boolean convertToEMI(int billId, int months) {
        Bill bill = getBillById(billId);
        if (bill == null || bill.isPaid()) return false;

        BigDecimal emiAmount = bill.getTotalAmount()
                .multiply(new BigDecimal("1.015")) // 1.5% interest per month
                .divide(new BigDecimal(months), 2, java.math.RoundingMode.CEILING);

        java.time.YearMonth start = java.time.YearMonth.parse(bill.getBillMonth()).plusMonths(1);
        // Mark original bill as paid (converted)
        String markSql = "UPDATE bills SET is_paid = 1, paid_amount = total_amount WHERE bill_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(markSql)) {
            ps.setInt(1, billId);
            ps.executeUpdate();
        } catch (SQLException e) {
            return false;
        }

        // Insert EMI bills
        String insertSql = "INSERT INTO bills (card_id, bill_month, total_amount, minimum_due, due_date) VALUES(?,?,?,?,?)";
        for (int i = 0; i < months; i++) {
            java.time.YearMonth ym = start.plusMonths(i);
            java.sql.Date due = java.sql.Date.valueOf(ym.atEndOfMonth());
            try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
                ps.setInt(1, bill.getCardId());
                ps.setString(2, "EMI-" + ym.toString());
                ps.setBigDecimal(3, emiAmount);
                ps.setBigDecimal(4, emiAmount);
                ps.setDate(5, due);
                ps.executeUpdate();
            } catch (SQLException e) {
                System.err.println("[BillDAO] convertToEMI insert error: " + e.getMessage());
            }
        }
        return true;
    }
}
