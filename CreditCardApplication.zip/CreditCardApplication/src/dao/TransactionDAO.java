package dao;

import models.Transaction;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    private Connection conn;

    public TransactionDAO() {
        this.conn = DBConnection.getConnection();
    }

    // ── Helper: map ResultSet row → Transaction object ──────────
    private Transaction mapRow(ResultSet rs) throws SQLException {
        return new Transaction(
            rs.getInt("txn_id"),
            rs.getInt("card_id"),
            rs.getBigDecimal("amount"),
            rs.getString("txn_type"),
            rs.getString("description"),
            rs.getTimestamp("txn_date")
        );
    }

    // ────────────────────────────────────────────────────────────
    // addTransaction — record any transaction
    // ────────────────────────────────────────────────────────────
    public boolean addTransaction(int cardId, BigDecimal amount,
                                   String txnType, String description) {
        String sql = "INSERT INTO transactions (card_id, amount, txn_type, description) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setBigDecimal(2, amount);
            ps.setString(3, txnType);
            ps.setString(4, description);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TransactionDAO] addTransaction error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // getTransactionsByCard — full history for a card
    // ────────────────────────────────────────────────────────────
    public List<Transaction> getTransactionsByCard(int cardId) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE card_id = ? ORDER BY txn_date DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[TransactionDAO] getTransactionsByCard error: " + e.getMessage());
        }
        return list;
    }

    // ────────────────────────────────────────────────────────────
    // getTransactionsByMonth — for billing: filter by card + month
    // ────────────────────────────────────────────────────────────
    public List<Transaction> getTransactionsByMonth(int cardId, String yearMonth) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE card_id = ? " +
                     "AND DATE_FORMAT(txn_date, '%Y-%m') = ? ORDER BY txn_date";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setString(2, yearMonth);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[TransactionDAO] getTransactionsByMonth error: " + e.getMessage());
        }
        return list;
    }

    // ────────────────────────────────────────────────────────────
    // getTotalSpendingByMonth — sum of PURCHASE + CASH_ADVANCE
    // ────────────────────────────────────────────────────────────
    public BigDecimal getTotalSpendingByMonth(int cardId, String yearMonth) {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM transactions " +
                     "WHERE card_id = ? AND DATE_FORMAT(txn_date, '%Y-%m') = ? " +
                     "AND txn_type IN ('PURCHASE','CASH_ADVANCE')";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setString(2, yearMonth);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getBigDecimal(1);
        } catch (SQLException e) {
            System.err.println("[TransactionDAO] getTotalSpendingByMonth error: " + e.getMessage());
        }
        return BigDecimal.ZERO;
    }

    // ────────────────────────────────────────────────────────────
    // getAllTransactions — admin dashboard view
    // ────────────────────────────────────────────────────────────
    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions ORDER BY txn_date DESC LIMIT 100";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[TransactionDAO] getAllTransactions error: " + e.getMessage());
        }
        return list;
    }
}
