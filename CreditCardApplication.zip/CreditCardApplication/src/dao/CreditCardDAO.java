package dao;

import models.CreditCard;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CreditCardDAO {

    private Connection conn;

    public CreditCardDAO() {
        this.conn = DBConnection.getConnection();
    }

    // ── Helper: map ResultSet row → CreditCard object ───────────
    private CreditCard mapRow(ResultSet rs) throws SQLException {
        return new CreditCard(
            rs.getInt("card_id"),
            rs.getString("card_number"),
            rs.getInt("user_id"),
            rs.getBigDecimal("credit_limit"),
            rs.getBigDecimal("available_balance"),
            rs.getString("status"),
            rs.getDate("expiry_date"),
            rs.getString("pin"),
            rs.getString("cvv"),
            rs.getString("card_type")
        );
    }

    // ── Generate a unique 16-digit card number ──────────────────
    private String generateCardNumber() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int g = 0; g < 4; g++) {
            if (g > 0) sb.append("-");
            for (int d = 0; d < 4; d++) sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    // ── Generate a 3-digit CVV ──────────────────────────────────
    private String generateCVV() {
        return String.format("%03d", new Random().nextInt(1000));
    }

    // ────────────────────────────────────────────────────────────
    // applyForCard — customer submits application (status = PENDING)
    // ────────────────────────────────────────────────────────────
    public boolean applyForCard(int userId, String cardType) {
        String cardNumber = generateCardNumber();
        String cvv = generateCVV();
        // Expiry: 5 years from now
        java.sql.Date expiry = java.sql.Date.valueOf(
                java.time.LocalDate.now().plusYears(5));
        String sql = "INSERT INTO credit_cards " +
                     "(card_number, user_id, credit_limit, available_balance, status, expiry_date, cvv, card_type) " +
                     "VALUES (?, ?, 50000.00, 50000.00, 'PENDING', ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cardNumber);
            ps.setInt(2, userId);
            ps.setDate(3, expiry);
            ps.setString(4, cvv);
            ps.setString(5, cardType);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] applyForCard error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // issueCard — admin approves: PENDING → ACTIVE
    // ────────────────────────────────────────────────────────────
    public boolean issueCard(int cardId) {
        String sql = "UPDATE credit_cards SET status = 'ACTIVE' WHERE card_id = ? AND status = 'PENDING'";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] issueCard error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // blockCard — restrict card use immediately
    // ────────────────────────────────────────────────────────────
    public boolean blockCard(int cardId) {
        String sql = "UPDATE credit_cards SET status = 'BLOCKED' WHERE card_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] blockCard error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // unblockCard — restore card: BLOCKED → ACTIVE
    // ────────────────────────────────────────────────────────────
    public boolean unblockCard(int cardId) {
        String sql = "UPDATE credit_cards SET status = 'ACTIVE' WHERE card_id = ? AND status = 'BLOCKED'";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] unblockCard error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // updateCreditLimit — admin sets new credit ceiling
    // ────────────────────────────────────────────────────────────
    public boolean updateCreditLimit(int cardId, BigDecimal newLimit) {
        String sql = "UPDATE credit_cards SET credit_limit = ?, available_balance = available_balance + (? - credit_limit) WHERE card_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, newLimit);
            ps.setBigDecimal(2, newLimit);
            ps.setInt(3, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] updateCreditLimit error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // checkBalance — returns CreditCard object with balance info
    // ────────────────────────────────────────────────────────────
    public CreditCard checkBalance(int cardId) {
        return getCardById(cardId);
    }

    // ────────────────────────────────────────────────────────────
    // setPin — set/change 4-digit PIN (stored as MD5)
    // ────────────────────────────────────────────────────────────
    public boolean setPin(int cardId, String newPin) {
        String sql = "UPDATE credit_cards SET pin = MD5(?) WHERE card_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPin);
            ps.setInt(2, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] setPin error: " + e.getMessage());
            return false;
        }
    }

    // ── Verify PIN ──────────────────────────────────────────────
    public boolean verifyPin(int cardId, String pin) {
        String sql = "SELECT card_id FROM credit_cards WHERE card_id = ? AND pin = MD5(?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ps.setString(2, pin);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] verifyPin error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // getCardById — fetch full card details
    // ────────────────────────────────────────────────────────────
    public CreditCard getCardById(int cardId) {
        String sql = "SELECT * FROM credit_cards WHERE card_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cardId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] getCardById error: " + e.getMessage());
        }
        return null;
    }

    // ────────────────────────────────────────────────────────────
    // getCardsByUserId — all cards for a customer
    // ────────────────────────────────────────────────────────────
    public List<CreditCard> getCardsByUserId(int userId) {
        List<CreditCard> cards = new ArrayList<>();
        String sql = "SELECT * FROM credit_cards WHERE user_id = ? ORDER BY card_id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) cards.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] getCardsByUserId error: " + e.getMessage());
        }
        return cards;
    }

    // ────────────────────────────────────────────────────────────
    // getAllCards — admin use
    // ────────────────────────────────────────────────────────────
    public List<CreditCard> getAllCards() {
        List<CreditCard> cards = new ArrayList<>();
        String sql = "SELECT * FROM credit_cards ORDER BY card_id";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) cards.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] getAllCards error: " + e.getMessage());
        }
        return cards;
    }

    // ── getPendingCards — for admin approval ────────────────────
    public List<CreditCard> getPendingCards() {
        List<CreditCard> cards = new ArrayList<>();
        String sql = "SELECT * FROM credit_cards WHERE status = 'PENDING'";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) cards.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] getPendingCards error: " + e.getMessage());
        }
        return cards;
    }

    // ── Deduct balance when spending ────────────────────────────
    public boolean deductBalance(int cardId, BigDecimal amount) {
        String sql = "UPDATE credit_cards SET available_balance = available_balance - ? " +
                     "WHERE card_id = ? AND available_balance >= ? AND status = 'ACTIVE'";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setInt(2, cardId);
            ps.setBigDecimal(3, amount);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] deductBalance error: " + e.getMessage());
            return false;
        }
    }

    // ── Restore balance when payment made ───────────────────────
    public boolean restoreBalance(int cardId, BigDecimal amount) {
        String sql = "UPDATE credit_cards SET available_balance = LEAST(available_balance + ?, credit_limit) " +
                     "WHERE card_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setInt(2, cardId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CreditCardDAO] restoreBalance error: " + e.getMessage());
            return false;
        }
    }
}
