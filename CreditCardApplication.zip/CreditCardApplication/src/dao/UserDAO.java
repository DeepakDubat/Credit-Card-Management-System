package dao;

import models.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private Connection conn;

    public UserDAO() {
        this.conn = DBConnection.getConnection();
    }

    // ── Helper: map ResultSet row → User object ─────────────────
    private User mapRow(ResultSet rs) throws SQLException {
        return new User(
            rs.getInt("user_id"),
            rs.getString("user_name"),
            rs.getString("password"),
            rs.getString("email"),
            rs.getString("phone_no"),
            rs.getString("role"),
            rs.getBoolean("is_active"),
            rs.getInt("age"),
            rs.getString("profile_pic_path")
        );
    }

    // ────────────────────────────────────────────────────────────
    // registerUser — insert new customer (password MD5-hashed in DB)
    // Returns true if successful
    // ────────────────────────────────────────────────────────────
    public boolean registerUser(String userName, String password,
                                 String email, String phoneNo) {
        String sql = "INSERT INTO users (user_name, password, email, phone_no, role) " +
                     "VALUES (?, MD5(?), ?, ?, 'CUSTOMER')";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setString(4, phoneNo);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] registerUser error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // loginUser — authenticate by username + password
    // Returns User object if valid, null if not found
    // ────────────────────────────────────────────────────────────
    public User loginUser(String userName, String password) {
        String sql = "SELECT * FROM users WHERE user_name = ? AND password = MD5(?) AND is_active = 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[UserDAO] loginUser error: " + e.getMessage());
        }
        return null;
    }

    // ────────────────────────────────────────────────────────────
    // updateProfile — update email and phone number
    // ────────────────────────────────────────────────────────────
    public boolean updateProfile(int userId, String newEmail, String newPhone, int age, String profilePicPath) {
        String sql = "UPDATE users SET email = ?, phone_no = ?, age = ?, profile_pic_path = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newEmail);
            ps.setString(2, newPhone);
            ps.setInt(3, age);
            ps.setString(4, profilePicPath);
            ps.setInt(5, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] updateProfile error: " + e.getMessage());
            return false;
        }
    }

    public boolean updateBasicProfile(int userId, String newEmail, String newPhone) {
        String sql = "UPDATE users SET email = ?, phone_no = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newEmail);
            ps.setString(2, newPhone);
            ps.setInt(3, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // adminUpdateUser — powerful update for admin management
    // ────────────────────────────────────────────────────────────
    public boolean adminUpdateUser(int userId, String userName, String email, String phone, String role, boolean isActive, int age) {
        String sql = "UPDATE users SET user_name = ?, email = ?, phone_no = ?, role = ?, is_active = ?, age = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, role);
            ps.setBoolean(5, isActive);
            ps.setInt(6, age);
            ps.setInt(7, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] adminUpdateUser error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // changePassword — update password (verifies old password first)
    // ────────────────────────────────────────────────────────────
    public boolean changePassword(int userId, String oldPassword, String newPassword) {
        // verify old password
        String checkSql = "SELECT user_id FROM users WHERE user_id = ? AND password = MD5(?)";
        try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
            ps.setInt(1, userId);
            ps.setString(2, oldPassword);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) return false; // old password wrong
        } catch (SQLException e) {
            System.err.println("[UserDAO] changePassword check error: " + e.getMessage());
            return false;
        }
        // update to new password
        String updateSql = "UPDATE users SET password = MD5(?) WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] changePassword update error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // deleteAccount — soft delete (marks is_active = 0)
    // ────────────────────────────────────────────────────────────
    public boolean deleteAccount(int userId) {
        String sql = "UPDATE users SET is_active = 0 WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] deleteAccount error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // getUserById — fetch single user
    // ────────────────────────────────────────────────────────────
    public User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[UserDAO] getUserById error: " + e.getMessage());
        }
        return null;
    }

    // ────────────────────────────────────────────────────────────
    // getAllUsers — list all users (Admin use)
    // ────────────────────────────────────────────────────────────
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY user_id";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) users.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[UserDAO] getAllUsers error: " + e.getMessage());
        }
        return users;
    }

    // ────────────────────────────────────────────────────────────
    // isUsernameTaken — check uniqueness before registration
    // ────────────────────────────────────────────────────────────
    public boolean isUsernameTaken(String userName) {
        String sql = "SELECT user_id FROM users WHERE user_name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("[UserDAO] isUsernameTaken error: " + e.getMessage());
            return false;
        }
    }

    // ────────────────────────────────────────────────────────────
    // isEmailTaken — check uniqueness before registration
    // ────────────────────────────────────────────────────────────
    public boolean isEmailTaken(String email) {
        String sql = "SELECT user_id FROM users WHERE email = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("[UserDAO] isEmailTaken error: " + e.getMessage());
            return false;
        }
    }
}
