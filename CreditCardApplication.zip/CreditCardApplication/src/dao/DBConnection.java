package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection — Singleton JDBC connection to MySQL.
 *
 * HOW TO CONFIGURE:
 * 1. Change DB_URL if your MySQL port/host is different.
 * 2. Change DB_USER and DB_PASSWORD to your MySQL credentials.
 * 3. Add mysql-connector-j-x.x.x.jar to NetBeans project libraries.
 */
public class DBConnection {

    // ── Change these values to match your MySQL setup ──────────
    private static final String DB_URL = "jdbc:mysql://localhost:3306/credit_card_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "deep@3731"; // <-- change this
    // ───────────────────────────────────────────────────────────

    private static Connection connection = null;

    private DBConnection() {
    } // prevent instantiation

    /**
     * Returns a singleton Connection object.
     * Creates a new connection if none exists or if the current one is closed.
     */
    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Load the MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                System.out.println("[DB] Connected to MySQL database successfully.");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("[DB ERROR] MySQL JDBC Driver not found!");
            System.err.println("           Please add mysql-connector-j.jar to project libraries.");
            System.exit(1);
        } catch (SQLException e) {
            System.err.println("[DB ERROR] Connection failed: " + e.getMessage());
            System.err.println("           Check DB_URL, DB_USER, DB_PASSWORD in DBConnection.java");
            System.exit(1);
        }
        return connection;
    }

    /** Close the connection (call on app exit). */
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("[DB] Connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("[DB ERROR] Could not close connection: " + e.getMessage());
        }
    }
}
