package services;

import dao.BillDAO;
import dao.CreditCardDAO;
import dao.TransactionDAO;
import models.Bill;
import models.CreditCard;
import java.math.BigDecimal;
import java.util.List;

public class BillingService {

    private final BillDAO       billDAO = new BillDAO();
    private final CreditCardDAO cardDAO = new CreditCardDAO();
    private final TransactionDAO txnDAO  = new TransactionDAO();
    private final TransactionService txnService = new TransactionService();

    // ────────────────────────────────────────────────────────────
    // generateBill — create a bill for card + month (YYYY-MM)
    // ────────────────────────────────────────────────────────────
    public String generateBill(int cardId, String billMonth) {
        if (billMonth == null || !billMonth.matches("\\d{4}-\\d{2}"))
            return "ERROR: Bill month must be in YYYY-MM format. Example: 2026-03";
        CreditCard card = cardDAO.getCardById(cardId);
        if (card == null) return "ERROR: Card ID " + cardId + " not found.";

        // Check if bill already exists
        if (billDAO.billExists(cardId, billMonth))
            return "ERROR: A bill for card #" + cardId + " in " + billMonth + " already exists.";

        // Check if there are any transactions for that month
        BigDecimal total = txnDAO.getTotalSpendingByMonth(cardId, billMonth);
        if (total.compareTo(BigDecimal.ZERO) == 0)
            return "ERROR: No transactions found for card #" + cardId + " in " + billMonth
                 + ". Make some purchases first, then generate the bill.";

        boolean ok = billDAO.generateBill(cardId, billMonth);
        return ok ? "SUCCESS: Bill generated for card #" + cardId + " — Month: " + billMonth
                     + "  |  Total: ₹" + total
                  : "ERROR: Database error while creating bill. Please try again.";
    }

    // ────────────────────────────────────────────────────────────
    // makePayment — pay a specific bill
    // ────────────────────────────────────────────────────────────
    public String makePayment(int billId, double paymentVal, int cardId) {
        if (paymentVal <= 0) return "ERROR: Payment amount must be positive.";
        Bill bill = billDAO.getBillById(billId);
        if (bill == null) return "ERROR: Bill not found.";
        if (bill.isPaid())  return "INFO: This bill is already fully paid.";

        BigDecimal minDue = bill.getMinimumDue();
        BigDecimal payment = BigDecimal.valueOf(paymentVal);
        if (payment.compareTo(minDue) < 0)
            return "ERROR: Minimum due is ₹" + minDue + ". Payment too low.";

        boolean billUpdated = billDAO.makePayment(billId, payment);
        if (!billUpdated) return "ERROR: Payment processing failed.";

        // Also restore card balance
        txnService.processPayment(cardId, paymentVal);
        return "SUCCESS: Payment of ₹" + payment + " recorded for Bill #" + billId + ".";
    }

    // ────────────────────────────────────────────────────────────
    // convertToEMI — split bill into monthly installments
    // ────────────────────────────────────────────────────────────
    public String convertToEMI(int billId, int months) {
        if (months < 2 || months > 24)
            return "ERROR: EMI tenure must be between 2 and 24 months.";
        Bill bill = billDAO.getBillById(billId);
        if (bill == null) return "ERROR: Bill not found.";
        if (bill.isPaid())  return "ERROR: Bill is already paid. Cannot convert.";

        boolean ok = billDAO.convertToEMI(billId, months);
        return ok ? "SUCCESS: Bill #" + billId + " converted to " + months + "-month EMI (1.5%/month interest)."
                  : "ERROR: EMI conversion failed.";
    }

    // ────────────────────────────────────────────────────────────
    // getStatement — all bills for a card
    // ────────────────────────────────────────────────────────────
    public List<Bill> getStatement(int cardId) {
        return billDAO.getStatementByCard(cardId);
    }

    // ── Bill by ID ───────────────────────────────────────────────
    public Bill getBillById(int billId) {
        return billDAO.getBillById(billId);
    }

    // ── All unpaid bills (Admin) ─────────────────────────────────
    public List<Bill> getAllUnpaidBills() {
        return billDAO.getAllUnpaidBills();
    }
}
