package services;

import dao.UserDAO;
import models.User;
import java.util.List;

public class UserService {

    private final UserDAO userDAO = new UserDAO();

    // ────────────────────────────────────────────────────────────
    // registerUser — validates inputs then calls DAO
    // ────────────────────────────────────────────────────────────
    public String registerUser(String userName, String password,
                                String email, String phoneNo) {
        if (userName == null || userName.trim().isEmpty())
            return "ERROR: Username cannot be empty.";
        if (userName.length() < 4)
            return "ERROR: Username must be at least 4 characters.";
        if (password == null || password.length() < 6)
            return "ERROR: Password must be at least 6 characters.";
        if (email == null || !email.contains("@"))
            return "ERROR: Invalid email address.";
        if (phoneNo == null || phoneNo.length() < 10)
            return "ERROR: Phone number must be at least 10 digits.";

        if (userDAO.isUsernameTaken(userName.trim()))
            return "ERROR: Username '" + userName + "' is already taken.";
        if (userDAO.isEmailTaken(email.trim()))
            return "ERROR: Email is already registered.";

        boolean ok = userDAO.registerUser(
                userName.trim(), password, email.trim(), phoneNo.trim());
        return ok ? "SUCCESS: Registration successful! You can now login."
                  : "ERROR: Registration failed. Please try again.";
    }

    // ────────────────────────────────────────────────────────────
    // loginUser — returns User if credentials match, null otherwise
    // ────────────────────────────────────────────────────────────
    public User loginUser(String userName, String password) {
        if (userName == null || password == null) return null;
        return userDAO.loginUser(userName.trim(), password);
    }

    // ────────────────────────────────────────────────────────────
    public String updateProfile(int userId, String newEmail, String newPhone) {
        if (newEmail == null || !newEmail.contains("@")) return "ERROR: Invalid email address.";
        if (newPhone == null || newPhone.length() < 10) return "ERROR: Phone number must be at least 10 digits.";
        boolean ok = userDAO.updateBasicProfile(userId, newEmail.trim(), newPhone.trim());
        return ok ? "SUCCESS: Profile updated successfully." : "ERROR: Update failed. Please try again.";
    }

    // ────────────────────────────────────────────────────────────
    public String updateProfileWithoutPassword(int userId, String email, String phone, int age, String profilePic) {
        if (email == null || !email.contains("@")) return "ERROR: Invalid email address.";
        if (phone == null || phone.length() < 10) return "ERROR: Phone number must be at least 10 digits.";
        if (age < 18) return "ERROR: Age must be at least 18.";

        boolean ok = userDAO.updateProfile(userId, email.trim(), phone.trim(), age, profilePic == null ? "" : profilePic.trim());
        return ok ? "SUCCESS: Profile updated successfully." : "ERROR: Update failed. Please try again.";
    }

    // ────────────────────────────────────────────────────────────
    public String updateFullProfile(int userId, String newEmail, String newPhone, int age, String profilePic, String oldPass, String newPass, String confirmPass) {
        if (newEmail == null || !newEmail.contains("@")) return "ERROR: Invalid email address.";
        if (newPhone == null || newPhone.length() < 10) return "ERROR: Phone number must be at least 10 digits.";
        if (age < 18) return "ERROR: Age must be at least 18.";
        if (profilePic == null || profilePic.trim().isEmpty()) return "ERROR: Profile picture is required.";
        if (newPass == null || newPass.length() < 6) return "ERROR: New password must be at least 6 characters.";
        if (!newPass.equals(confirmPass)) return "ERROR: New password and Confirm password do not match.";

        // Attempting to change password first to verify old password
        boolean passwordChanged = userDAO.changePassword(userId, oldPass, newPass);
        if (!passwordChanged) {
            return "ERROR: Old password is incorrect.";
        }

        boolean profileUpdated = userDAO.updateProfile(userId, newEmail.trim(), newPhone.trim(), age, profilePic.trim());
        if (profileUpdated) {
            return "SUCCESS: Profile updated successfully.";
        } else {
            return "ERROR: Password updated but profile changes failed.";
        }
    }

    // ────────────────────────────────────────────────────────────
    // adminUpdateUser — Validates and updates user for admin
    // ────────────────────────────────────────────────────────────
    public String adminUpdateUser(int userId, String userName, String email, String phone, String role, boolean isActive, int age) {
        if (userName == null || userName.trim().isEmpty()) return "ERROR: Username cannot be empty.";
        if (email == null || !email.contains("@")) return "ERROR: Invalid email address.";
        if (phone == null || phone.length() < 10) return "ERROR: Phone number must be at least 10 digits.";
        if (age < 18) return "ERROR: Age must be at least 18.";

        boolean ok = userDAO.adminUpdateUser(userId, userName.trim(), email.trim(), phone.trim(), role, isActive, age);
        return ok ? "SUCCESS: User updated successfully." : "ERROR: Failed to update user.";
    }

    // ────────────────────────────────────────────────────────────
    // changePassword
    // ────────────────────────────────────────────────────────────
    public String changePassword(int userId, String oldPass, String newPass) {
        if (newPass == null || newPass.length() < 6)
            return "ERROR: New password must be at least 6 characters.";
        if (oldPass.equals(newPass))
            return "ERROR: New password must be different from old password.";
        boolean ok = userDAO.changePassword(userId, oldPass, newPass);
        return ok ? "SUCCESS: Password changed successfully."
                  : "ERROR: Old password is incorrect.";
    }

    // ────────────────────────────────────────────────────────────
    // deleteAccount
    // ────────────────────────────────────────────────────────────
    public String deleteAccount(int userId) {
        boolean ok = userDAO.deleteAccount(userId);
        return ok ? "SUCCESS: Account deactivated successfully."
                  : "ERROR: Could not deactivate account.";
    }

    // ────────────────────────────────────────────────────────────
    // getUserById
    // ────────────────────────────────────────────────────────────
    public User getUserById(int userId) {
        return userDAO.getUserById(userId);
    }

    // ────────────────────────────────────────────────────────────
    // getAllUsers (Admin)
    // ────────────────────────────────────────────────────────────
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
}
