package services;

import dao.BillDAO;
import dao.CreditCardDAO;
import dao.TransactionDAO;
import dao.UserDAO;
import models.Bill;
import models.CreditCard;
import models.Transaction;
import models.User;
import java.math.BigDecimal;
import java.util.List;

public class ReportService {

    private final UserDAO        userDAO  = new UserDAO();
    private final CreditCardDAO  cardDAO  = new CreditCardDAO();
    private final TransactionDAO txnDAO   = new TransactionDAO();
    private final BillDAO        billDAO  = new BillDAO();

    // ────────────────────────────────────────────────────────────
    // monthlySummary — spending summary for a card in a given month
    // ────────────────────────────────────────────────────────────
    public void monthlySummary(int cardId, String yearMonth) {
        List<Transaction> txns = txnDAO.getTransactionsByMonth(cardId, yearMonth);
        BigDecimal totalSpend = BigDecimal.ZERO;
        BigDecimal totalPaid  = BigDecimal.ZERO;

        System.out.println("\n  ══════════════════════════════════════════");
        System.out.println("     MONTHLY STATEMENT — " + yearMonth);
        System.out.println("  ══════════════════════════════════════════");
        if (txns.isEmpty()) {
            System.out.println("  No transactions found for " + yearMonth + ".");
        } else {
            for (Transaction t : txns) {
                System.out.println(t.toString());
                if ("PURCHASE".equals(t.getTxnType()) || "CASH_ADVANCE".equals(t.getTxnType())) {
                    totalSpend = totalSpend.add(t.getAmount());
                } else if ("PAYMENT".equals(t.getTxnType()) || "REFUND".equals(t.getTxnType())) {
                    totalPaid = totalPaid.add(t.getAmount());
                }
            }
            System.out.println("  ──────────────────────────────────────────");
            System.out.printf("  Total Spending  : ₹%.2f%n", totalSpend);
            System.out.printf("  Total Payments  : ₹%.2f%n", totalPaid);
            System.out.printf("  Net Outstanding : ₹%.2f%n", totalSpend.subtract(totalPaid));
        }
        System.out.println("  ══════════════════════════════════════════");
    }

    // ────────────────────────────────────────────────────────────
    // spendingAnalysis — category breakdown for a card
    // ────────────────────────────────────────────────────────────
    public void spendingAnalysis(int cardId) {
        List<Transaction> txns = txnDAO.getTransactionsByCard(cardId);
        BigDecimal purchases = BigDecimal.ZERO;
        BigDecimal cashAdv   = BigDecimal.ZERO;
        BigDecimal payments  = BigDecimal.ZERO;
        BigDecimal refunds   = BigDecimal.ZERO;

        for (Transaction t : txns) {
            switch (t.getTxnType()) {
                case "PURCHASE"     -> purchases = purchases.add(t.getAmount());
                case "CASH_ADVANCE" -> cashAdv   = cashAdv.add(t.getAmount());
                case "PAYMENT"      -> payments  = payments.add(t.getAmount());
                case "REFUND"       -> refunds   = refunds.add(t.getAmount());
            }
        }

        System.out.println("\n  ══════════════════════════════════════════");
        System.out.println("     SPENDING ANALYSIS — Card #" + cardId);
        System.out.println("  ══════════════════════════════════════════");
        System.out.printf("  Purchases       : ₹%.2f%n", purchases);
        System.out.printf("  Cash Advances   : ₹%.2f%n", cashAdv);
        System.out.printf("  Payments Made   : ₹%.2f%n", payments);
        System.out.printf("  Refunds         : ₹%.2f%n", refunds);
        System.out.printf("  Net Outstanding : ₹%.2f%n",
                purchases.add(cashAdv).subtract(payments).subtract(refunds));
        System.out.println("  ══════════════════════════════════════════");
    }

    // ────────────────────────────────────────────────────────────
    // adminDashboard — overview of entire system
    // ────────────────────────────────────────────────────────────
    public void adminDashboard() {
        List<User>        users    = userDAO.getAllUsers();
        List<CreditCard>  cards    = cardDAO.getAllCards();
        List<Transaction> txns     = txnDAO.getAllTransactions();
        List<Bill>        unpaid   = billDAO.getAllUnpaidBills();

        long customers = users.stream().filter(u -> "CUSTOMER".equals(u.getRole())).count();
        long active    = cards.stream().filter(c -> "ACTIVE".equals(c.getStatus())).count();
        long pending   = cards.stream().filter(c -> "PENDING".equals(c.getStatus())).count();
        long blocked   = cards.stream().filter(c -> "BLOCKED".equals(c.getStatus())).count();

        BigDecimal totalRevenue = txns.stream()
            .filter(t -> "PURCHASE".equals(t.getTxnType()) || "CASH_ADVANCE".equals(t.getTxnType()))
            .map(Transaction::getAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal outstandingDues = unpaid.stream()
            .map(b -> b.getTotalAmount().subtract(b.getPaidAmount()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        System.out.println("\n  ╔══════════════════════════════════════════╗");
        System.out.println("  ║         ADMIN DASHBOARD                  ║");
        System.out.println("  ╠══════════════════════════════════════════╣");
        System.out.printf ("  ║  Total Users      : %-21d║%n", users.size());
        System.out.printf ("  ║  Customers        : %-21d║%n", customers);
        System.out.printf ("  ║  Total Cards      : %-21d║%n", cards.size());
        System.out.printf ("  ║  Active Cards     : %-21d║%n", active);
        System.out.printf ("  ║  Pending Approval : %-21d║%n", pending);
        System.out.printf ("  ║  Blocked Cards    : %-21d║%n", blocked);
        System.out.printf ("  ║  Total Txns (100) : %-21d║%n", txns.size());
        System.out.printf ("  ║  Total Volume     : ₹%-20.2f║%n", totalRevenue);
        System.out.printf ("  ║  Unpaid Bills     : %-21d║%n", unpaid.size());
        System.out.printf ("  ║  Outstanding Dues : ₹%-20.2f║%n", outstandingDues);
        System.out.println("  ╚══════════════════════════════════════════╝");
    }
}
