package services;

import dao.CreditCardDAO;
import dao.TransactionDAO;
import models.CreditCard;
import java.math.BigDecimal;
import java.util.List;

public class CardService {

    private final CreditCardDAO cardDAO = new CreditCardDAO();
    private final TransactionDAO txnDAO = new TransactionDAO();

    // ────────────────────────────────────────────────────────────
    // applyForCard — customer submits card application
    // ────────────────────────────────────────────────────────────
    public String applyForCard(int userId, String cardType) {
        String type = (cardType == null || cardType.isBlank()) ? "VISA" : cardType.trim().toUpperCase();
        boolean ok = cardDAO.applyForCard(userId, type);
        return ok ? "SUCCESS: Card application submitted! Awaiting admin approval."
                  : "ERROR: Card application failed.";
    }

    // ────────────────────────────────────────────────────────────
    // issueCard — admin approves pending card
    // ────────────────────────────────────────────────────────────
    public String issueCard(int cardId) {
        boolean ok = cardDAO.issueCard(cardId);
        return ok ? "SUCCESS: Card #" + cardId + " has been activated."
                  : "ERROR: Card not found or not in PENDING status.";
    }

    // ────────────────────────────────────────────────────────────
    // blockCard — immediately stop all transactions
    // ────────────────────────────────────────────────────────────
    public String blockCard(int cardId) {
        boolean ok = cardDAO.blockCard(cardId);
        return ok ? "SUCCESS: Card #" + cardId + " has been BLOCKED."
                  : "ERROR: Could not block card.";
    }

    // ────────────────────────────────────────────────────────────
    // unblockCard — restore blocked card
    // ────────────────────────────────────────────────────────────
    public String unblockCard(int cardId) {
        boolean ok = cardDAO.unblockCard(cardId);
        return ok ? "SUCCESS: Card #" + cardId + " has been UNBLOCKED."
                  : "ERROR: Card not found or not in BLOCKED status.";
    }

    // ────────────────────────────────────────────────────────────
    // updateCreditLimit — admin adjusts limit
    // ────────────────────────────────────────────────────────────
    public String updateCreditLimit(int cardId, double newLimitVal) {
        if (newLimitVal <= 0) return "ERROR: Credit limit must be positive.";
        BigDecimal newLimit = BigDecimal.valueOf(newLimitVal);
        boolean ok = cardDAO.updateCreditLimit(cardId, newLimit);
        return ok ? "SUCCESS: Credit limit updated to ₹" + newLimit
                  : "ERROR: Could not update credit limit.";
    }

    // ────────────────────────────────────────────────────────────
    // checkBalance — view available vs used credit
    // ────────────────────────────────────────────────────────────
    public String checkBalance(int cardId) {
        CreditCard card = cardDAO.checkBalance(cardId);
        if (card == null) return "ERROR: Card not found.";
        BigDecimal used = card.getCreditLimit().subtract(card.getAvailableBalance());
        return String.format(
            "%n  Credit Limit    : ₹%.2f%n" +
            "  Used Credit     : ₹%.2f%n" +
            "  Available Bal   : ₹%.2f%n" +
            "  Card Status     : %s",
            card.getCreditLimit(), used, card.getAvailableBalance(), card.getStatus()
        );
    }

    // ────────────────────────────────────────────────────────────
    // getCardDetails
    // ────────────────────────────────────────────────────────────
    public CreditCard getCardDetails(int cardId) {
        return cardDAO.getCardById(cardId);
    }

    // ────────────────────────────────────────────────────────────
    // getCardsByUser — all cards for a customer
    // ────────────────────────────────────────────────────────────
    public List<CreditCard> getCardsByUser(int userId) {
        return cardDAO.getCardsByUserId(userId);
    }

    // ────────────────────────────────────────────────────────────
    // getAllCards — admin view
    // ────────────────────────────────────────────────────────────
    public List<CreditCard> getAllCards() {
        return cardDAO.getAllCards();
    }

    // ────────────────────────────────────────────────────────────
    // getPendingCards — admin approval queue
    // ────────────────────────────────────────────────────────────
    public List<CreditCard> getPendingCards() {
        return cardDAO.getPendingCards();
    }
}
