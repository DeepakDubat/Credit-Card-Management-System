package services;

import dao.CreditCardDAO;
import dao.TransactionDAO;
import models.CreditCard;
import models.Transaction;
import java.math.BigDecimal;
import java.util.List;

public class TransactionService {

    private final TransactionDAO txnDAO  = new TransactionDAO();
    private final CreditCardDAO  cardDAO = new CreditCardDAO();

    // ────────────────────────────────────────────────────────────
    // makePurchase — debit card, record PURCHASE transaction
    // ────────────────────────────────────────────────────────────
    public String makePurchase(int cardId, double amountVal, String description) {
        if (amountVal <= 0) return "ERROR: Amount must be positive.";
        CreditCard card = cardDAO.getCardById(cardId);
        if (card == null)  return "ERROR: Card not found.";
        if (!"ACTIVE".equals(card.getStatus()))
            return "ERROR: Card is " + card.getStatus() + ". Cannot process transaction.";

        BigDecimal amount = BigDecimal.valueOf(amountVal);
        if (card.getAvailableBalance().compareTo(amount) < 0)
            return "ERROR: Insufficient credit balance. Available: ₹" + card.getAvailableBalance();

        boolean deducted = cardDAO.deductBalance(cardId, amount);
        if (!deducted) return "ERROR: Transaction failed. Please try again.";

        boolean recorded = txnDAO.addTransaction(cardId, amount, "PURCHASE",
                description == null || description.isBlank() ? "Purchase" : description);
        return recorded ? "SUCCESS: Purchase of ₹" + amount + " processed successfully."
                        : "WARNING: Amount deducted but transaction log failed.";
    }

    // ────────────────────────────────────────────────────────────
    // cashAdvance — withdraw cash against credit card (3% fee applied)
    // ────────────────────────────────────────────────────────────
    public String cashAdvance(int cardId, double amountVal) {
        if (amountVal <= 0) return "ERROR: Amount must be positive.";
        CreditCard card = cardDAO.getCardById(cardId);
        if (card == null)  return "ERROR: Card not found.";
        if (!"ACTIVE".equals(card.getStatus()))
            return "ERROR: Card is " + card.getStatus() + ".";

        // Cash advance fee = 3%
        BigDecimal base   = BigDecimal.valueOf(amountVal);
        BigDecimal fee    = base.multiply(new BigDecimal("0.03")).setScale(2, java.math.RoundingMode.CEILING);
        BigDecimal total  = base.add(fee);

        if (card.getAvailableBalance().compareTo(total) < 0)
            return "ERROR: Insufficient balance. Available: ₹" + card.getAvailableBalance()
                 + " (required with 3% fee: ₹" + total + ")";

        boolean deducted = cardDAO.deductBalance(cardId, total);
        if (!deducted) return "ERROR: Cash advance failed.";

        txnDAO.addTransaction(cardId, total, "CASH_ADVANCE",
                "Cash Advance ₹" + base + " + Fee ₹" + fee);
        return "SUCCESS: Cash advance of ₹" + base + " processed. Fee: ₹" + fee + ". Total: ₹" + total;
    }

    // ────────────────────────────────────────────────────────────
    // processPayment — restore balance, record PAYMENT transaction
    // ────────────────────────────────────────────────────────────
    public String processPayment(int cardId, double amountVal) {
        if (amountVal <= 0) return "ERROR: Payment amount must be positive.";
        BigDecimal amount = BigDecimal.valueOf(amountVal);

        boolean restored = cardDAO.restoreBalance(cardId, amount);
        if (!restored) return "ERROR: Payment failed.";

        txnDAO.addTransaction(cardId, amount, "PAYMENT", "Bill Payment");
        return "SUCCESS: Payment of ₹" + amount + " recorded. Balance restored.";
    }

    // ────────────────────────────────────────────────────────────
    // refund — return amount to card balance
    // ────────────────────────────────────────────────────────────
    public String refund(int cardId, double amountVal, String reason) {
        if (amountVal <= 0) return "ERROR: Refund amount must be positive.";
        BigDecimal amount = BigDecimal.valueOf(amountVal);

        boolean restored = cardDAO.restoreBalance(cardId, amount);
        if (!restored) return "ERROR: Refund failed.";

        txnDAO.addTransaction(cardId, amount, "REFUND",
                "Refund: " + (reason == null ? "N/A" : reason));
        return "SUCCESS: Refund of ₹" + amount + " processed.";
    }

    // ────────────────────────────────────────────────────────────
    // getTransactionHistory — list all txns for a card
    // ────────────────────────────────────────────────────────────
    public List<Transaction> getTransactionHistory(int cardId) {
        return txnDAO.getTransactionsByCard(cardId);
    }

    // ── All transactions — Admin ─────────────────────────────────
    public List<Transaction> getAllTransactions() {
        return txnDAO.getAllTransactions();
    }
}
