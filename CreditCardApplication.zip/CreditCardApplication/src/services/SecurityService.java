package services;

import dao.CreditCardDAO;
import java.util.Random;

public class SecurityService {

    private final CreditCardDAO cardDAO = new CreditCardDAO();
    private static String lastOtp = null;   // simple in-memory OTP (single-user session)

    // ────────────────────────────────────────────────────────────
    // generateOTP — produce a 6-digit OTP and display it
    // (In production this would be sent via SMS/email)
    // ────────────────────────────────────────────────────────────
    public String generateOTP(String phoneOrEmail) {
        lastOtp = String.format("%06d", new Random().nextInt(1000000));
        // Simulating SMS/email delivery
        System.out.println("\n  [OTP SYSTEM] Sending OTP to: " + phoneOrEmail);
        System.out.println("  ──────────────────────────────");
        System.out.println("  Your OTP is: " + lastOtp + "  (valid for 5 minutes)");
        System.out.println("  ──────────────────────────────");
        return "OTP sent to " + phoneOrEmail;
    }

    // ────────────────────────────────────────────────────────────
    // validateOTP — check if entered OTP matches
    // ────────────────────────────────────────────────────────────
    public boolean validateOTP(String enteredOtp) {
        if (lastOtp == null) return false;
        boolean valid = lastOtp.equals(enteredOtp.trim());
        if (valid) lastOtp = null;   // OTP used up
        return valid;
    }

    // ────────────────────────────────────────────────────────────
    // setPIN — set or change 4-digit PIN
    // ────────────────────────────────────────────────────────────
    public String setPIN(int cardId, String newPin) {
        if (newPin == null || !newPin.matches("\\d{4}"))
            return "ERROR: PIN must be exactly 4 digits.";
        boolean ok = cardDAO.setPin(cardId, newPin);
        return ok ? "SUCCESS: PIN set successfully."
                  : "ERROR: Could not set PIN.";
    }

    // ────────────────────────────────────────────────────────────
    // verifyPIN — check if entered PIN is correct
    // ────────────────────────────────────────────────────────────
    public boolean verifyPIN(int cardId, String pin) {
        if (pin == null || !pin.matches("\\d{4}")) return false;
        return cardDAO.verifyPin(cardId, pin);
    }

    // ────────────────────────────────────────────────────────────
    // lockCard (alias for blockCard through security context)
    // ────────────────────────────────────────────────────────────
    public String lockCard(int cardId) {
        boolean ok = cardDAO.blockCard(cardId);
        return ok ? "SUCCESS: Card #" + cardId + " has been LOCKED for security."
                  : "ERROR: Could not lock card.";
    }

    // ────────────────────────────────────────────────────────────
    // unlockCard — after OTP verification, unblock card
    // ────────────────────────────────────────────────────────────
    public String unlockCard(int cardId, String enteredOtp) {
        if (!validateOTP(enteredOtp))
            return "ERROR: Invalid OTP. Card remains locked.";
        boolean ok = cardDAO.unblockCard(cardId);
        return ok ? "SUCCESS: Card #" + cardId + " has been UNLOCKED."
                  : "ERROR: Card is not in BLOCKED state.";
    }
}
