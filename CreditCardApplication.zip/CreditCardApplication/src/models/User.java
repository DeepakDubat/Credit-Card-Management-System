package models;

public class User {
    private int userId;
    private String userName;
    private String password;
    private String email;
    private String phoneNo;
    private String role;      // "ADMIN" or "CUSTOMER"
    private boolean isActive;
    private int age;
    private String profilePicPath;

    // ─── Constructors ──────────────────────────────────────────
    public User() {}

    public User(int userId, String userName, String password,
                String email, String phoneNo, String role, boolean isActive,
                int age, String profilePicPath) {
        this.userId   = userId;
        this.userName = userName;
        this.password = password;
        this.email    = email;
        this.phoneNo  = phoneNo;
        this.role     = role;
        this.isActive = isActive;
        this.age      = age;
        this.profilePicPath = profilePicPath;
    }

    // ─── Getters ───────────────────────────────────────────────
    public int     getUserId()   { return userId;   }
    public String  getUserName() { return userName; }
    public String  getPassword() { return password; }
    public String  getEmail()    { return email;    }
    public String  getPhoneNo()  { return phoneNo;  }
    public String  getRole()     { return role;     }
    public boolean isActive()    { return isActive; }
    public int     getAge()      { return age;      }
    public String  getProfilePicPath() { return profilePicPath; }

    // ─── Setters ───────────────────────────────────────────────
    public void setUserId(int userId)       { this.userId   = userId;   }
    public void setUserName(String u)       { this.userName = u;        }
    public void setPassword(String p)       { this.password = p;        }
    public void setEmail(String e)          { this.email    = e;        }
    public void setPhoneNo(String p)        { this.phoneNo  = p;        }
    public void setRole(String r)           { this.role     = r;        }
    public void setActive(boolean a)        { this.isActive = a;        }
    public void setAge(int a)               { this.age      = a;        }
    public void setProfilePicPath(String p) { this.profilePicPath = p;  }

    @Override
    public String toString() {
        return String.format(
            "┌─────────────────────────────────────┐%n" +
            "│  User ID   : %-24d│%n" +
            "│  Username  : %-24s│%n" +
            "│  Email     : %-24s│%n" +
            "│  Phone     : %-24s│%n" +
            "│  Role      : %-24s│%n" +
            "│  Status    : %-24s│%n" +
            "└─────────────────────────────────────┘",
            userId, userName, email, phoneNo, role, isActive ? "Active" : "Inactive"
        );
    }
}
