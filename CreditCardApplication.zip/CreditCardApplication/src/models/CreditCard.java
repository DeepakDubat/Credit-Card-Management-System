package models;

import java.math.BigDecimal;
import java.sql.Date;

public class CreditCard {
    private int        cardId;
    private String     cardNumber;
    private int        userId;
    private BigDecimal creditLimit;
    private BigDecimal availableBalance;
    private String     status;      // PENDING / ACTIVE / BLOCKED / EXPIRED / CANCELLED
    private Date       expiryDate;
    private String     pin;         // MD5 hashed (stored), null if not set
    private String     cvv;
    private String     cardType;

    // ─── Constructors ──────────────────────────────────────────
    public CreditCard() {}

    public CreditCard(int cardId, String cardNumber, int userId,
                      BigDecimal creditLimit, BigDecimal availableBalance,
                      String status, Date expiryDate, String pin,
                      String cvv, String cardType) {
        this.cardId           = cardId;
        this.cardNumber       = cardNumber;
        this.userId           = userId;
        this.creditLimit      = creditLimit;
        this.availableBalance = availableBalance;
        this.status           = status;
        this.expiryDate       = expiryDate;
        this.pin              = pin;
        this.cvv              = cvv;
        this.cardType         = cardType;
    }

    // ─── Getters ───────────────────────────────────────────────
    public int        getCardId()           { return cardId;           }
    public String     getCardNumber()       { return cardNumber;       }
    public int        getUserId()           { return userId;           }
    public BigDecimal getCreditLimit()      { return creditLimit;      }
    public BigDecimal getAvailableBalance() { return availableBalance; }
    public String     getStatus()           { return status;           }
    public Date       getExpiryDate()       { return expiryDate;       }
    public String     getPin()              { return pin;              }
    public String     getCvv()              { return cvv;              }
    public String     getCardType()         { return cardType;         }

    // ─── Setters ───────────────────────────────────────────────
    public void setCardId(int cardId)                       { this.cardId           = cardId;           }
    public void setCardNumber(String cardNumber)            { this.cardNumber       = cardNumber;       }
    public void setUserId(int userId)                       { this.userId           = userId;           }
    public void setCreditLimit(BigDecimal creditLimit)      { this.creditLimit      = creditLimit;      }
    public void setAvailableBalance(BigDecimal ab)          { this.availableBalance = ab;               }
    public void setStatus(String status)                    { this.status           = status;           }
    public void setExpiryDate(Date expiryDate)              { this.expiryDate       = expiryDate;       }
    public void setPin(String pin)                          { this.pin              = pin;              }
    public void setCvv(String cvv)                          { this.cvv              = cvv;              }
    public void setCardType(String cardType)                { this.cardType         = cardType;         }

    // Mask card number for display: ****-****-****-4892
    public String getMaskedCardNumber() {
        if (cardNumber == null || cardNumber.length() < 4) return cardNumber;
        return "****-****-****-" + cardNumber.substring(cardNumber.length() - 4);
    }

    @Override
    public String toString() {
        return String.format(
            "┌─────────────────────────────────────────┐%n" +
            "│  Card ID        : %-22d│%n" +
            "│  Card Number    : %-22s│%n" +
            "│  Type           : %-22s│%n" +
            "│  Status         : %-22s│%n" +
            "│  Credit Limit   : ₹%-21.2f│%n" +
            "│  Available Bal  : ₹%-21.2f│%n" +
            "│  Expiry Date    : %-22s│%n" +
            "└─────────────────────────────────────────┘",
            cardId, getMaskedCardNumber(), cardType, status,
            creditLimit, availableBalance, expiryDate
        );
    }
}
