package models;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Transaction {
    private int       txnId;
    private int       cardId;
    private BigDecimal amount;
    private String    txnType;       // PURCHASE / CASH_ADVANCE / PAYMENT / REFUND
    private String    description;
    private Timestamp txnDate;

    // ─── Constructors ──────────────────────────────────────────
    public Transaction() {}

    public Transaction(int txnId, int cardId, BigDecimal amount,
                       String txnType, String description, Timestamp txnDate) {
        this.txnId       = txnId;
        this.cardId      = cardId;
        this.amount      = amount;
        this.txnType     = txnType;
        this.description = description;
        this.txnDate     = txnDate;
    }

    // ─── Getters ───────────────────────────────────────────────
    public int        getTxnId()      { return txnId;       }
    public int        getCardId()     { return cardId;      }
    public BigDecimal getAmount()     { return amount;      }
    public String     getTxnType()    { return txnType;     }
    public String     getDescription(){ return description; }
    public Timestamp  getTxnDate()    { return txnDate;     }

    // ─── Setters ───────────────────────────────────────────────
    public void setTxnId(int txnId)           { this.txnId       = txnId;       }
    public void setCardId(int cardId)         { this.cardId      = cardId;      }
    public void setAmount(BigDecimal amount)  { this.amount      = amount;      }
    public void setTxnType(String txnType)    { this.txnType     = txnType;     }
    public void setDescription(String desc)   { this.description = desc;        }
    public void setTxnDate(Timestamp txnDate) { this.txnDate     = txnDate;     }

    @Override
    public String toString() {
        String sign = (txnType.equals("PAYMENT") || txnType.equals("REFUND")) ? "+" : "-";
        return String.format("  [%d] %-16s | %s₹%-10.2f | %-30s | %s",
                txnId, txnType, sign, amount, description, txnDate);
    }
}
