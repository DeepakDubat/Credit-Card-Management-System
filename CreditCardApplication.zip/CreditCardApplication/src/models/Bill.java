package models;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class Bill {
    private int        billId;
    private int        cardId;
    private String     billMonth;     // format: YYYY-MM
    private BigDecimal totalAmount;
    private BigDecimal minimumDue;
    private Date       dueDate;
    private boolean    isPaid;
    private BigDecimal paidAmount;
    private Timestamp  createdAt;

    // ─── Constructors ──────────────────────────────────────────
    public Bill() {}

    public Bill(int billId, int cardId, String billMonth,
                BigDecimal totalAmount, BigDecimal minimumDue,
                Date dueDate, boolean isPaid, BigDecimal paidAmount,
                Timestamp createdAt) {
        this.billId      = billId;
        this.cardId      = cardId;
        this.billMonth   = billMonth;
        this.totalAmount = totalAmount;
        this.minimumDue  = minimumDue;
        this.dueDate     = dueDate;
        this.isPaid      = isPaid;
        this.paidAmount  = paidAmount;
        this.createdAt   = createdAt;
    }

    // ─── Getters ───────────────────────────────────────────────
    public int        getBillId()      { return billId;      }
    public int        getCardId()      { return cardId;      }
    public String     getBillMonth()   { return billMonth;   }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public BigDecimal getMinimumDue()  { return minimumDue;  }
    public Date       getDueDate()     { return dueDate;     }
    public boolean    isPaid()         { return isPaid;      }
    public BigDecimal getPaidAmount()  { return paidAmount;  }
    public Timestamp  getCreatedAt()   { return createdAt;   }

    // ─── Setters ───────────────────────────────────────────────
    public void setBillId(int billId)               { this.billId      = billId;      }
    public void setCardId(int cardId)               { this.cardId      = cardId;      }
    public void setBillMonth(String billMonth)      { this.billMonth   = billMonth;   }
    public void setTotalAmount(BigDecimal t)        { this.totalAmount = t;           }
    public void setMinimumDue(BigDecimal m)         { this.minimumDue  = m;           }
    public void setDueDate(Date dueDate)            { this.dueDate     = dueDate;     }
    public void setPaid(boolean isPaid)             { this.isPaid      = isPaid;      }
    public void setPaidAmount(BigDecimal paidAmount){ this.paidAmount  = paidAmount;  }
    public void setCreatedAt(Timestamp createdAt)   { this.createdAt   = createdAt;   }

    @Override
    public String toString() {
        return String.format(
            "┌────────────────────────────────────────────┐%n" +
            "│  Bill ID      : %-27d│%n" +
            "│  Card ID      : %-27d│%n" +
            "│  Bill Month   : %-27s│%n" +
            "│  Total Amount : ₹%-26.2f│%n" +
            "│  Minimum Due  : ₹%-26.2f│%n" +
            "│  Paid Amount  : ₹%-26.2f│%n" +
            "│  Due Date     : %-27s│%n" +
            "│  Status       : %-27s│%n" +
            "└────────────────────────────────────────────┘",
            billId, cardId, billMonth, totalAmount, minimumDue,
            paidAmount, dueDate, isPaid ? "PAID" : "PENDING"
        );
    }
}
