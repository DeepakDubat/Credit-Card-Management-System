import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBUpdater {
    public static void main(String[] args) {
        String dbUrl = "jdbc:mysql://localhost:3306/credit_card_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";
        String pass = "deep@3731";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(dbUrl, user, pass);
            Statement stmt = conn.createStatement();
            try {
                stmt.executeUpdate("ALTER TABLE users ADD COLUMN age INT DEFAULT 0");
                System.out.println("Column 'age' added.");
            } catch (Exception e) {
                System.out.println("Column 'age' may already exist.");
            }
            try {
                stmt.executeUpdate("ALTER TABLE users ADD COLUMN profile_pic_path VARCHAR(255) DEFAULT NULL");
                System.out.println("Column 'profile_pic_path' added.");
            } catch (Exception e) {
                System.out.println("Column 'profile_pic_path' may already exist.");
            }
            conn.close();
            System.out.println("DB update complete.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
