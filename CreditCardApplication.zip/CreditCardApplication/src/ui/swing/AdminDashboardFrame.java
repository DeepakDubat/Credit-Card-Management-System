package ui.swing;

import models.Bill;
import models.CreditCard;
import models.User;
import services.BillingService;
import services.CardService;
import services.UserService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.List;

public class AdminDashboardFrame extends JFrame {

    private final User adminUser;
    private final CardService cardService = new CardService();
    private final UserService userService = new UserService();
    private final BillingService billingService = new BillingService();

    private DefaultTableModel pendingModel;
    private DefaultTableModel allCardsModel;
    private DefaultTableModel userModel;
    private DefaultTableModel billsLogModel;

    private JComboBox<String> statusFilter;
    private JTextField minBalField, maxBalField, minLimField, maxLimField;

    private JLabel profilePicLabel;
    private JLabel userNameLabel;
    private String tempPicPath;

    public AdminDashboardFrame(User adminUser) {
        this.adminUser = adminUser;
        setTitle("Admin Dashboard — " + adminUser.getUserName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 680);
        setLocationRelativeTo(null);

        // ── Top bar ──────────────────────────────────────────────
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(30, 39, 46));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));

        // Left: profile + name
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 3));
        leftPanel.setOpaque(false);
        profilePicLabel = new JLabel(getProfileIcon(adminUser.getProfilePicPath(), 42, 42));
        userNameLabel = new JLabel(adminUser.getUserName());
        userNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        userNameLabel.setForeground(new Color(200, 214, 229));

        JLabel adminBadge = new JLabel("  ADMIN");
        adminBadge.setFont(new Font("Segoe UI", Font.BOLD, 10));
        adminBadge.setForeground(new Color(30, 39, 46));
        adminBadge.setBackground(new Color(241, 196, 15));
        adminBadge.setOpaque(true);
        adminBadge.setBorder(BorderFactory.createEmptyBorder(3, 6, 3, 6));

        leftPanel.add(profilePicLabel);
        leftPanel.add(userNameLabel);
        leftPanel.add(adminBadge);
        topPanel.add(leftPanel, BorderLayout.WEST);

        // Right: nav buttons
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        rightPanel.setOpaque(false);

        JButton refreshBtn    = makeNavButton("⟳ Refresh",     new Color(39, 174, 96));
        JButton editProfileBtn = makeNavButton("✎ Edit Profile", new Color(52, 152, 219));
        JButton logoutBtn     = makeNavButton("⏻ Logout",       new Color(192, 57, 43));

        refreshBtn.addActionListener(e -> refreshTables());
        editProfileBtn.addActionListener(e -> openEditProfileDialog());
        logoutBtn.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });

        rightPanel.add(refreshBtn);
        rightPanel.add(editProfileBtn);
        rightPanel.add(logoutBtn);
        topPanel.add(rightPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // ── Tabs ─────────────────────────────────────────────────
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.addTab("👥  Manage Users",       createManageUsersPanel());
        tabs.addTab("⏳  Pending Approvals",  createPendingCardsPanel());
        tabs.addTab("💳  All Cards",           createAllCardsPanel());
        tabs.addTab("🧾  Generate Bills",      createBillingPanel());

        add(tabs, BorderLayout.CENTER);
        refreshTables();
    }

    // ── Helpers ──────────────────────────────────────────────────
    private JButton makeNavButton(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private ImageIcon getProfileIcon(String path, int w, int h) {
        BufferedImage circle = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = circle.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new Ellipse2D.Float(0, 0, w, h));

        boolean loaded = false;
        if (path != null && !path.trim().isEmpty()) {
            File f = new File(path);
            if (f.exists()) {
                try {
                    BufferedImage img = ImageIO.read(f);
                    if (img != null) {
                        g2.drawImage(img.getScaledInstance(w, h, Image.SCALE_SMOOTH), 0, 0, null);
                        loaded = true;
                    }
                } catch (Exception ignored) {}
            }
        }
        if (!loaded) {
            g2.setColor(new Color(241, 196, 15));
            g2.fillRect(0, 0, w, h);
            g2.setColor(new Color(30, 39, 46));
            g2.setFont(new Font("Segoe UI", Font.BOLD, h / 2));
            String init = adminUser != null ? String.valueOf(adminUser.getUserName().charAt(0)).toUpperCase() : "A";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(init, (w - fm.stringWidth(init)) / 2, (h + fm.getAscent() - fm.getDescent()) / 2);
        }
        g2.dispose();
        return new ImageIcon(circle);
    }

    // ── Edit Profile dialog ──────────────────────────────────────
    private void openEditProfileDialog() {
        tempPicPath = adminUser.getProfilePicPath();

        JDialog dlg = new JDialog(this, "Admin Profile", true);
        dlg.setSize(430, 460);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setBackground(Color.WHITE);

        // Dark header with profile picture
        JPanel header = new JPanel();
        header.setBackground(new Color(30, 39, 46));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(BorderFactory.createEmptyBorder(18, 0, 18, 0));

        JLabel picLbl = new JLabel(getProfileIcon(tempPicPath, 90, 90));
        picLbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        picLbl.setToolTipText("Click to change photo");
        picLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        picLbl.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JFileChooser fc = new JFileChooser();
                if (fc.showOpenDialog(dlg) == JFileChooser.APPROVE_OPTION) {
                    tempPicPath = fc.getSelectedFile().getAbsolutePath();
                    picLbl.setIcon(getProfileIcon(tempPicPath, 90, 90));
                }
            }
        });
        JLabel hint = new JLabel("Click photo to change");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(new Color(127, 140, 141));
        hint.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(picLbl);
        header.add(Box.createVerticalStrut(6));
        header.add(hint);
        main.add(header, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 12));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createEmptyBorder(20, 25, 10, 25));

        JLabel nl = new JLabel("Username:"); nl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField nf = new JTextField(adminUser.getUserName()); nf.setEditable(false);
        nf.setBackground(new Color(236, 240, 241));

        JLabel el = new JLabel("Email: *"); el.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField ef = new JTextField(adminUser.getEmail());

        JLabel pl = new JLabel("Phone: *"); pl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField pf = new JTextField(adminUser.getPhoneNo());

        JLabel al = new JLabel("Age: *"); al.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField af = new JTextField(adminUser.getAge() == 0 ? "" : String.valueOf(adminUser.getAge()));

        form.add(nl); form.add(nf);
        form.add(el); form.add(ef);
        form.add(pl); form.add(pf);
        form.add(al); form.add(af);
        main.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 12));
        btnRow.setBackground(Color.WHITE);
        JButton chgPwdBtn = makeNavButton("🔒 Change Password", new Color(52, 73, 94));
        JButton saveBtn   = makeNavButton("✔ Save Changes",     new Color(39, 174, 96));

        chgPwdBtn.addActionListener(e -> openChangePasswordDialog(dlg));
        saveBtn.addActionListener(e -> {
            String email = ef.getText().trim();
            String phone = pf.getText().trim();
            String ageStr = af.getText().trim();
            if (email.isEmpty() || phone.isEmpty() || ageStr.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Email, Phone and Age are required."); return;
            }
            try {
                int age = Integer.parseInt(ageStr);
                String res = userService.updateProfileWithoutPassword(adminUser.getUserId(), email, phone, age, tempPicPath);
                JOptionPane.showMessageDialog(dlg, res);
                if (res.startsWith("SUCCESS")) {
                    adminUser.setEmail(email); adminUser.setPhoneNo(phone);
                    adminUser.setAge(age); adminUser.setProfilePicPath(tempPicPath);
                    profilePicLabel.setIcon(getProfileIcon(tempPicPath, 42, 42));
                    dlg.dispose();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg, "Invalid age value.");
            }
        });
        btnRow.add(chgPwdBtn);
        btnRow.add(saveBtn);
        main.add(btnRow, BorderLayout.SOUTH);

        dlg.setContentPane(main);
        dlg.setVisible(true);
    }

    // ── Change Password dialog ───────────────────────────────────
    private void openChangePasswordDialog(JDialog parent) {
        JDialog d = new JDialog(parent, "Change Password", true);
        d.setSize(340, 260);
        d.setLocationRelativeTo(parent);
        d.setResizable(false);

        JPanel main = new JPanel(new BorderLayout());
        JPanel hdr = new JPanel();
        hdr.setBackground(new Color(30, 39, 46));
        hdr.setBorder(BorderFactory.createEmptyBorder(14, 0, 14, 0));
        JLabel title = new JLabel("🔒 Change Password");
        title.setFont(new Font("Segoe UI", Font.BOLD, 15));
        title.setForeground(Color.WHITE);
        hdr.add(title);
        main.add(hdr, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 12));
        form.setBorder(BorderFactory.createEmptyBorder(20, 25, 10, 25));

        JLabel ol = new JLabel("Old Password:"); ol.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField opF = new JPasswordField();
        JLabel newl = new JLabel("New Password:"); newl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField npF = new JPasswordField();
        JLabel cl = new JLabel("Confirm Pass:"); cl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField cpF = new JPasswordField();

        form.add(ol); form.add(opF);
        form.add(newl); form.add(npF);
        form.add(cl); form.add(cpF);
        main.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel();
        JButton updateBtn = makeNavButton("Update Password", new Color(39, 174, 96));
        updateBtn.addActionListener(e -> {
            String o = new String(opF.getPassword());
            String n = new String(npF.getPassword());
            String c = new String(cpF.getPassword());
            if (o.isEmpty() || n.isEmpty()) {
                JOptionPane.showMessageDialog(d, "All fields are required."); return;
            }
            if (!n.equals(c)) {
                JOptionPane.showMessageDialog(d, "New passwords do not match!"); return;
            }
            String res = userService.changePassword(adminUser.getUserId(), o, n);
            JOptionPane.showMessageDialog(d, res);
            if (res.startsWith("SUCCESS")) d.dispose();
        });
        btnRow.add(updateBtn);
        main.add(btnRow, BorderLayout.SOUTH);

        d.setContentPane(main);
        d.setVisible(true);
    }

    // ── Manage Users panel ───────────────────────────────────────
    private JPanel createManageUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // ── Filter bar ────────────────────────────────────────────
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterBar.setBackground(new Color(245, 246, 250));
        filterBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(189, 195, 199)));

        JLabel statusLbl = new JLabel("Status:");
        statusLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"All", "Active", "Not Active"});
        statusBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JLabel roleLbl = new JLabel("  Role:");
        roleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"All", "CUSTOMER", "ADMIN"});
        roleBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JButton applyFilter = makeNavButton("Filter", new Color(41, 128, 185));
        JButton clearFilter = makeNavButton("Clear",  new Color(127, 140, 141));

        filterBar.add(statusLbl); filterBar.add(statusBox);
        filterBar.add(roleLbl);   filterBar.add(roleBox);
        filterBar.add(applyFilter); filterBar.add(clearFilter);
        panel.add(filterBar, BorderLayout.NORTH);

        // ── Table ─────────────────────────────────────────────────
        String[] cols = {"User ID", "Username", "Email", "Phone", "Role", "Active", "Age"};
        userModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(userModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(24);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(30, 39, 46));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(52, 152, 219));
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        // Filter logic
        Runnable doFilter = () -> {
            String selStatus = (String) statusBox.getSelectedItem();
            String selRole   = (String) roleBox.getSelectedItem();
            userModel.setRowCount(0);
            for (User u : userService.getAllUsers()) {
                boolean mSt = "All".equals(selStatus)
                    || ("Active".equals(selStatus) && u.isActive())
                    || ("Not Active".equals(selStatus) && !u.isActive());
                boolean mRl = "All".equals(selRole) || u.getRole().equalsIgnoreCase(selRole);
                if (mSt && mRl)
                    userModel.addRow(new Object[]{u.getUserId(), u.getUserName(), u.getEmail(),
                        u.getPhoneNo(), u.getRole(), u.isActive() ? "✓" : "✗", u.getAge()});
            }
        };
        applyFilter.addActionListener(e -> doFilter.run());
        clearFilter.addActionListener(e -> {
            statusBox.setSelectedIndex(0); roleBox.setSelectedIndex(0); doFilter.run();
        });

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton editBtn = makeNavButton("✎ Edit Selected User", new Color(41, 128, 185));
        editBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }
            int uid = (int) userModel.getValueAt(row, 0);
            User u = userService.getUserById(uid);
            if (u != null) openEditUserDialog(u);
        });
        bottom.add(editBtn);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    private void openEditUserDialog(User u) {
        JDialog dlg = new JDialog(this, "Edit User: " + u.getUserName(), true);
        dlg.setSize(400, 380);
        dlg.setLocationRelativeTo(this);

        JPanel p = new JPanel(new GridLayout(7, 2, 10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel ul = new JLabel("Username:"); ul.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField uF = new JTextField(u.getUserName());
        JLabel el = new JLabel("Email:"); el.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField eF = new JTextField(u.getEmail());
        JLabel phL = new JLabel("Phone:"); phL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField phF = new JTextField(u.getPhoneNo());
        JLabel al = new JLabel("Age:"); al.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField aF = new JTextField(String.valueOf(u.getAge()));
        JLabel rl = new JLabel("Role:"); rl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"CUSTOMER", "ADMIN"});
        roleBox.setSelectedItem(u.getRole());
        JLabel acL = new JLabel("Active:"); acL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JCheckBox activeBox = new JCheckBox("Is Active", u.isActive());

        p.add(ul); p.add(uF);
        p.add(el); p.add(eF);
        p.add(phL); p.add(phF);
        p.add(al); p.add(aF);
        p.add(rl); p.add(roleBox);
        p.add(acL); p.add(activeBox);

        JButton saveBtn = makeNavButton("✔ Save Changes", new Color(39, 174, 96));
        saveBtn.addActionListener(ev -> {
            try {
                int age = Integer.parseInt(aF.getText().trim());
                String res = userService.adminUpdateUser(u.getUserId(), uF.getText().trim(),
                    eF.getText().trim(), phF.getText().trim(),
                    roleBox.getSelectedItem().toString(), activeBox.isSelected(), age);
                JOptionPane.showMessageDialog(dlg, res);
                if (res.startsWith("SUCCESS")) { dlg.dispose(); refreshTables(); }
            } catch (Exception ex) { JOptionPane.showMessageDialog(dlg, "Invalid age."); }
        });
        p.add(new JLabel(""));
        p.add(saveBtn);

        dlg.add(p);
        dlg.setVisible(true);
    }

    // ── Pending approvals panel ──────────────────────────────────
    private JPanel createPendingCardsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] cols = {"Card ID", "Card Number", "User ID", "Type", "Status"};
        pendingModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(pendingModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(24);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(30, 39, 46));
        table.getTableHeader().setForeground(Color.WHITE);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton approveBtn = makeNavButton("✔ Approve Selected", new Color(39, 174, 96));
        approveBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a card first."); return; }
            int cid = (int) pendingModel.getValueAt(row, 0);
            JOptionPane.showMessageDialog(this, cardService.issueCard(cid));
            refreshTables();
        });
        bottom.add(approveBtn);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    // ── All Cards panel ──────────────────────────────────────────
    private JPanel createAllCardsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(createCardFilterPanel(), BorderLayout.NORTH);

        String[] cols = {"Card ID", "Card Number", "User ID", "Limit", "Balance", "Status"};
        allCardsModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(allCardsModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(24);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(30, 39, 46));
        table.getTableHeader().setForeground(Color.WHITE);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton blockBtn = makeNavButton("⊘ Block Card", new Color(192, 57, 43));
        blockBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            int cid = (int) allCardsModel.getValueAt(row, 0);
            cardService.blockCard(cid);
            JOptionPane.showMessageDialog(this, "Card blocked.");
            refreshTables();
        });
        bottom.add(blockBtn);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createCardFilterPanel() {
        JPanel fp = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fp.setBorder(BorderFactory.createTitledBorder("Filter Cards"));
        fp.add(new JLabel("Status:"));
        statusFilter = new JComboBox<>(new String[]{"All", "ACTIVE", "BLOCKED"});
        fp.add(statusFilter);
        fp.add(new JLabel("Min Bal:"));
        minBalField = new JTextField(5); fp.add(minBalField);
        fp.add(new JLabel("Max Bal:"));
        maxBalField = new JTextField(5); fp.add(maxBalField);
        fp.add(new JLabel("Min Limit:"));
        minLimField = new JTextField(5); fp.add(minLimField);
        fp.add(new JLabel("Max Limit:"));
        maxLimField = new JTextField(5); fp.add(maxLimField);

        JButton filterBtn = new JButton("Filter");
        filterBtn.addActionListener(e -> applyFilters());
        JButton clearBtn = new JButton("Clear");
        clearBtn.addActionListener(e -> {
            statusFilter.setSelectedIndex(0);
            minBalField.setText(""); maxBalField.setText("");
            minLimField.setText(""); maxLimField.setText("");
            applyFilters();
        });
        fp.add(filterBtn); fp.add(clearBtn);
        return fp;
    }

    private void applyFilters() {
        if (statusFilter == null || allCardsModel == null) return;
        String status = (String) statusFilter.getSelectedItem();
        BigDecimal minBal = parseSafe(minBalField.getText());
        BigDecimal maxBal = parseSafe(maxBalField.getText());
        BigDecimal minLim = parseSafe(minLimField.getText());
        BigDecimal maxLim = parseSafe(maxLimField.getText());

        allCardsModel.setRowCount(0);
        for (CreditCard c : cardService.getAllCards()) {
            boolean ms = "All".equals(status) || c.getStatus().equalsIgnoreCase(status);
            boolean mb = (minBal == null || c.getAvailableBalance().compareTo(minBal) >= 0)
                      && (maxBal == null || c.getAvailableBalance().compareTo(maxBal) <= 0);
            boolean ml = (minLim == null || c.getCreditLimit().compareTo(minLim) >= 0)
                      && (maxLim == null || c.getCreditLimit().compareTo(maxLim) <= 0);
            if (ms && mb && ml)
                allCardsModel.addRow(new Object[]{c.getCardId(), c.getCardNumber(), c.getUserId(),
                    c.getCreditLimit(), c.getAvailableBalance(), c.getStatus()});
        }
    }

    private BigDecimal parseSafe(String s) {
        try { return (s == null || s.isEmpty()) ? null : new BigDecimal(s.trim()); }
        catch (Exception e) { return null; }
    }

    // ── Generate Bills panel ─────────────────────────────────────
    private JPanel createBillingPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ── Top form ──────────────────────────────────────────────
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Generate New Bill"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Card selector dropdown (populated from all active cards)
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel cardLbl = new JLabel("Select Card:");
        cardLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        form.add(cardLbl, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        JComboBox<String> billCardBox = new JComboBox<>();
        billCardBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        populateCardDropdown(billCardBox);
        form.add(billCardBox, gbc);

        // Month selector — default to previous month
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        JLabel monthLbl = new JLabel("Bill Month:");
        monthLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        form.add(monthLbl, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        YearMonth prev = YearMonth.now().minusMonths(1);
        JTextField monthField = new JTextField(prev.toString(), 12);
        monthField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        form.add(monthField, gbc);

        gbc.gridx = 2; gbc.gridy = 1;
        JLabel hint = new JLabel("(YYYY-MM)");
        hint.setForeground(Color.GRAY);
        form.add(hint, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.NONE; gbc.anchor = GridBagConstraints.CENTER;
        JButton genBtn = makeNavButton("🧾 Generate Bill", new Color(41, 128, 185));
        genBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        form.add(genBtn, gbc);

        panel.add(form, BorderLayout.NORTH);

        // ── Bills log table ───────────────────────────────────────
        String[] cols = {"Bill ID", "Card ID", "Month", "Total Amount", "Min Due", "Due Date", "Paid?"};
        billsLogModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable billTable = new JTable(billsLogModel);
        billTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        billTable.setRowHeight(24);
        billTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        billTable.getTableHeader().setBackground(new Color(30, 39, 46));
        billTable.getTableHeader().setForeground(Color.WHITE);

        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setBorder(BorderFactory.createTitledBorder("Recent Bills Generated"));
        logPanel.add(new JScrollPane(billTable), BorderLayout.CENTER);
        panel.add(logPanel, BorderLayout.CENTER);

        // Generate button action
        genBtn.addActionListener(e -> {
            String sel = (String) billCardBox.getSelectedItem();
            if (sel == null || sel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select a card."); return;
            }
            String month = monthField.getText().trim();
            int cardId = Integer.parseInt(sel.split(" ")[0].trim());
            String res = billingService.generateBill(cardId, month);
            JOptionPane.showMessageDialog(this, res);
            refreshBillsLog();
        });

        refreshBillsLog();
        return panel;
    }

    private void populateCardDropdown(JComboBox<String> box) {
        box.removeAllItems();
        for (CreditCard c : cardService.getAllCards()) {
            if (!"BLOCKED".equalsIgnoreCase(c.getStatus())) {
                box.addItem(c.getCardId() + " — " + c.getCardNumber() + " (User " + c.getUserId() + ")");
            }
        }
    }

    private void refreshBillsLog() {
        if (billsLogModel == null) return;
        billsLogModel.setRowCount(0);
        List<Bill> bills = billingService.getAllUnpaidBills();
        for (Bill b : bills) {
            billsLogModel.addRow(new Object[]{
                b.getBillId(), b.getCardId(), b.getBillMonth(),
                "₹" + b.getTotalAmount(), "₹" + b.getMinimumDue(),
                b.getDueDate(), b.isPaid() ? "Yes" : "No"
            });
        }
    }

    // ── Refresh all tables ───────────────────────────────────────
    private void refreshTables() {
        // Pending
        if (pendingModel != null) {
            pendingModel.setRowCount(0);
            for (CreditCard c : cardService.getPendingCards())
                pendingModel.addRow(new Object[]{c.getCardId(), c.getCardNumber(), c.getUserId(), c.getCardType(), c.getStatus()});
        }
        // All cards
        applyFilters();
        // Users
        if (userModel != null) {
            userModel.setRowCount(0);
            for (User u : userService.getAllUsers())
                userModel.addRow(new Object[]{u.getUserId(), u.getUserName(), u.getEmail(), u.getPhoneNo(), u.getRole(), u.isActive(), u.getAge()});
        }
        // Bills log
        refreshBillsLog();
    }
}
