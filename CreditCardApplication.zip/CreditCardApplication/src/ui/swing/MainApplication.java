package ui.swing;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * MainApplication - The entry point for the Credit Card Desktop GUI.
 */
public class MainApplication {
    public static void main(String[] args) {
        // Apply Nimbus Look and Feel for better custom color support and enlarge fonts
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            // Global font adjustments
            java.awt.Font f = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 15);
            java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
            while (keys.hasMoreElements()) {
                Object key = keys.nextElement();
                Object value = UIManager.get(key);
                if (value instanceof javax.swing.plaf.FontUIResource) {
                    UIManager.put(key, new javax.swing.plaf.FontUIResource(f));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
