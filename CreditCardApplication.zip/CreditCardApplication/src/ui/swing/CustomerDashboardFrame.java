package ui.swing;

import models.CreditCard;
import models.Transaction;
import models.User;
import services.CardService;
import services.TransactionService;
import services.UserService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class CustomerDashboardFrame extends JFrame {
    private final User user;
    private final CardService cardService = new CardService();
    private final TransactionService txnSvc = new TransactionService();
    private final UserService userService = new UserService();

    private JPanel cardsPanel;
    private JComboBox<String> txnCardSelector;
    private JComboBox<String> historyCardSelector;
    private DefaultTableModel historyModel;

    private JLabel profilePicLabel;
    private JLabel userNameLabel;
    private String tempPicPath;

    public CustomerDashboardFrame(User user) {
        this.user = user;
        setTitle("My Dashboard - " + user.getUserName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 650);
        setLocationRelativeTo(null);

        // ── Top bar ──────────────────────────────────────────────
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(44, 62, 80));
        topPanel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));

        // Left: profile pic + name
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 2));
        leftPanel.setOpaque(false);
        profilePicLabel = new JLabel(getProfileIcon(user.getProfilePicPath(), 42, 42));
        userNameLabel = new JLabel(user.getUserName());
        userNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        userNameLabel.setForeground(Color.WHITE);
        leftPanel.add(profilePicLabel);
        leftPanel.add(userNameLabel);
        topPanel.add(leftPanel, BorderLayout.WEST);

        // Right: buttons
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        rightPanel.setOpaque(false);

        JButton refreshBtn  = makeNavButton("⟳ Refresh",    new Color(52, 152, 219));
        JButton editBtn     = makeNavButton("✎ Edit Profile", new Color(22, 160, 133));
        JButton logoutBtn   = makeNavButton("⏻ Logout",      new Color(192, 57, 43));

        refreshBtn.addActionListener(e -> refreshData());
        editBtn.addActionListener(e -> openEditProfileDialog());
        logoutBtn.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });

        rightPanel.add(refreshBtn);
        rightPanel.add(editBtn);
        rightPanel.add(logoutBtn);
        topPanel.add(rightPanel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // ── Tabs ─────────────────────────────────────────────────
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.addTab("💳  My Cards",        createCardsPanel());
        tabs.addTab("💸  Make Transaction", createTransactionsPanel());
        tabs.addTab("📋  Transaction History", createHistoryPanel());

        add(tabs, BorderLayout.CENTER);

        refreshData();
    }

    // ── Utility button factory ───────────────────────────────────
    private JButton makeNavButton(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── Round profile icon ───────────────────────────────────────
    private ImageIcon getProfileIcon(String path, int w, int h) {
        BufferedImage circle = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = circle.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new Ellipse2D.Float(0, 0, w, h));

        boolean loaded = false;
        if (path != null && !path.trim().isEmpty()) {
            File f = new File(path);
            if (f.exists()) {
                try {
                    BufferedImage img = ImageIO.read(f);
                    if (img != null) {
                        g2.drawImage(img.getScaledInstance(w, h, Image.SCALE_SMOOTH), 0, 0, null);
                        loaded = true;
                    }
                } catch (Exception ignored) {}
            }
        }
        if (!loaded) {
            g2.setColor(new Color(52, 152, 219));
            g2.fillRect(0, 0, w, h);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, h / 2));
            String initials = user != null ? String.valueOf(user.getUserName().charAt(0)).toUpperCase() : "?";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(initials, (w - fm.stringWidth(initials)) / 2, (h + fm.getAscent() - fm.getDescent()) / 2);
        }
        g2.dispose();
        return new ImageIcon(circle);
    }

    // ── Edit Profile dialog ──────────────────────────────────────
    private void openEditProfileDialog() {
        tempPicPath = user.getProfilePicPath();

        JDialog dlg = new JDialog(this, "Edit Profile", true);
        dlg.setSize(420, 450);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setBackground(Color.WHITE);

        // Picture top section (dark header)
        JPanel header = new JPanel();
        header.setBackground(new Color(44, 62, 80));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        JLabel picLbl = new JLabel(getProfileIcon(tempPicPath, 90, 90));
        picLbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        picLbl.setToolTipText("Click to change photo");
        picLbl.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JFileChooser fc = new JFileChooser();
                if (fc.showOpenDialog(dlg) == JFileChooser.APPROVE_OPTION) {
                    tempPicPath = fc.getSelectedFile().getAbsolutePath();
                    picLbl.setIcon(getProfileIcon(tempPicPath, 90, 90));
                }
            }
        });
        JLabel clickHint = new JLabel("Click photo to change");
        clickHint.setForeground(new Color(189, 195, 199));
        clickHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        picLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        clickHint.setAlignmentX(Component.CENTER_ALIGNMENT);
        header.add(picLbl);
        header.add(Box.createVerticalStrut(6));
        header.add(clickHint);
        main.add(header, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 12));
        form.setBorder(BorderFactory.createEmptyBorder(20, 25, 10, 25));
        form.setBackground(Color.WHITE);

        JLabel nameL = new JLabel("Username:"); nameL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField nameF = new JTextField(user.getUserName()); nameF.setEditable(false);
        nameF.setBackground(new Color(236, 240, 241));

        JLabel emailL = new JLabel("Email: *"); emailL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField emailF = new JTextField(user.getEmail());

        JLabel phoneL = new JLabel("Phone: *"); phoneL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField phoneF = new JTextField(user.getPhoneNo());

        JLabel ageL = new JLabel("Age: *"); ageL.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JTextField ageF = new JTextField(user.getAge() == 0 ? "" : String.valueOf(user.getAge()));

        form.add(nameL); form.add(nameF);
        form.add(emailL); form.add(emailF);
        form.add(phoneL); form.add(phoneF);
        form.add(ageL); form.add(ageF);
        main.add(form, BorderLayout.CENTER);

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 12));
        btnRow.setBackground(Color.WHITE);

        JButton changePwdBtn = makeNavButton("🔒 Change Password", new Color(52, 73, 94));
        JButton saveBtn = makeNavButton("✔ Save Changes", new Color(39, 174, 96));

        changePwdBtn.addActionListener(e -> openChangePasswordDialog(dlg));
        saveBtn.addActionListener(e -> {
            String email = emailF.getText().trim();
            String phone = phoneF.getText().trim();
            String ageStr = ageF.getText().trim();
            if (email.isEmpty() || phone.isEmpty() || ageStr.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Email, Phone and Age are required.");
                return;
            }
            try {
                int age = Integer.parseInt(ageStr);
                String res = userService.updateProfileWithoutPassword(
                    user.getUserId(), email, phone, age, tempPicPath);
                JOptionPane.showMessageDialog(dlg, res);
                if (res.startsWith("SUCCESS")) {
                    user.setEmail(email); user.setPhoneNo(phone);
                    user.setAge(age); user.setProfilePicPath(tempPicPath);
                    profilePicLabel.setIcon(getProfileIcon(tempPicPath, 42, 42));
                    dlg.dispose();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg, "Invalid age value.");
            }
        });

        btnRow.add(changePwdBtn);
        btnRow.add(saveBtn);
        main.add(btnRow, BorderLayout.SOUTH);

        dlg.setContentPane(main);
        dlg.setVisible(true);
    }

    // ── Change Password dialog ───────────────────────────────────
    private void openChangePasswordDialog(JDialog parent) {
        JDialog d = new JDialog(parent, "Change Password", true);
        d.setSize(350, 260);
        d.setLocationRelativeTo(parent);
        d.setResizable(false);

        JPanel main = new JPanel(new BorderLayout());
        // Header
        JPanel hdr = new JPanel();
        hdr.setBackground(new Color(44, 62, 80));
        hdr.setBorder(BorderFactory.createEmptyBorder(14, 0, 14, 0));
        JLabel title = new JLabel("🔒 Change Password");
        title.setFont(new Font("Segoe UI", Font.BOLD, 15));
        title.setForeground(Color.WHITE);
        hdr.add(title);
        main.add(hdr, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 12));
        form.setBorder(BorderFactory.createEmptyBorder(20, 25, 10, 25));

        JLabel ol = new JLabel("Old Password:"); ol.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField opF = new JPasswordField();
        JLabel nl = new JLabel("New Password:"); nl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField npF = new JPasswordField();
        JLabel cl = new JLabel("Confirm Pass:"); cl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPasswordField cpF = new JPasswordField();

        form.add(ol); form.add(opF);
        form.add(nl); form.add(npF);
        form.add(cl); form.add(cpF);
        main.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel();
        JButton updateBtn = makeNavButton("Update Password", new Color(39, 174, 96));
        updateBtn.addActionListener(e -> {
            String o = new String(opF.getPassword());
            String n = new String(npF.getPassword());
            String c = new String(cpF.getPassword());
            if (o.isEmpty() || n.isEmpty()) {
                JOptionPane.showMessageDialog(d, "All fields are required."); return;
            }
            if (!n.equals(c)) {
                JOptionPane.showMessageDialog(d, "New passwords do not match!"); return;
            }
            String res = userService.changePassword(user.getUserId(), o, n);
            JOptionPane.showMessageDialog(d, res);
            if (res.startsWith("SUCCESS")) d.dispose();
        });
        btnRow.add(updateBtn);
        main.add(btnRow, BorderLayout.SOUTH);

        d.setContentPane(main);
        d.setVisible(true);
    }

    // ── My Cards tab ─────────────────────────────────────────────
    private JPanel createCardsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));

        JPanel applyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        applyPanel.setBackground(new Color(245, 246, 250));
        String[] types = {"VISA", "MASTERCARD", "RUPAY"};
        JComboBox<String> typeBox = new JComboBox<>(types);
        typeBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JButton applyBtn = makeNavButton("+ Apply for New Card", new Color(41, 128, 185));
        applyBtn.addActionListener(e -> {
            String res = cardService.applyForCard(user.getUserId(), typeBox.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, res);
            refreshData();
        });
        applyPanel.add(new JLabel("Card Type:"));
        applyPanel.add(typeBox);
        applyPanel.add(applyBtn);
        panel.add(applyPanel, BorderLayout.NORTH);

        cardsPanel = new JPanel();
        cardsPanel.setLayout(new BoxLayout(cardsPanel, BoxLayout.Y_AXIS));
        cardsPanel.setBackground(new Color(245, 246, 250));
        panel.add(new JScrollPane(cardsPanel), BorderLayout.CENTER);
        return panel;
    }

    // ── Make Transaction tab ─────────────────────────────────────
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 12));
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(20, 30, 10, 30),
            BorderFactory.createTitledBorder("Transaction Details")));
        form.setBackground(Color.WHITE);

        txnCardSelector = new JComboBox<>();
        txnCardSelector.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JTextField amtF = new JTextField();
        JTextField descF = new JTextField();

        form.add(new JLabel("Select Card:")); form.add(txnCardSelector);
        form.add(new JLabel("Amount (₹):"));  form.add(amtF);
        form.add(new JLabel("Description:")); form.add(descF);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        btnRow.setBackground(new Color(245, 246, 250));
        JButton buyBtn  = makeNavButton("💳 Make Purchase",  new Color(39, 174, 96));
        JButton cashBtn = makeNavButton("💵 Cash Advance",   new Color(211, 84, 0));
        btnRow.add(buyBtn); btnRow.add(cashBtn);

        buyBtn.addActionListener(e -> {
            int cid = getSelectedCardId();
            if (cid == -1) { JOptionPane.showMessageDialog(this, "No card selected."); return; }
            try {
                double amt = Double.parseDouble(amtF.getText());
                JOptionPane.showMessageDialog(this, txnSvc.makePurchase(cid, amt, descF.getText()));
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid amount."); }
        });
        cashBtn.addActionListener(e -> {
            int cid = getSelectedCardId();
            if (cid == -1) { JOptionPane.showMessageDialog(this, "No card selected."); return; }
            try {
                double amt = Double.parseDouble(amtF.getText());
                JOptionPane.showMessageDialog(this, txnSvc.cashAdvance(cid, amt));
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid amount."); }
        });

        panel.add(form, BorderLayout.NORTH);
        panel.add(btnRow, BorderLayout.CENTER);
        return panel;
    }

    // ── Transaction History tab ──────────────────────────────────
    private JPanel createHistoryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        top.setBackground(new Color(245, 246, 250));
        top.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

        historyCardSelector = new JComboBox<>();
        historyCardSelector.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        historyCardSelector.setPreferredSize(new Dimension(280, 30));

        JButton loadBtn = makeNavButton("📋 Load History", new Color(41, 128, 185));
        top.add(new JLabel("Select Card:"));
        top.add(historyCardSelector);
        top.add(loadBtn);
        panel.add(top, BorderLayout.NORTH);

        String[] cols = {"Date & Time", "Card No", "Type", "Amount (₹)", "Description"};
        historyModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(historyModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(24);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(44, 62, 80));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(52, 152, 219));
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        loadBtn.addActionListener(e -> {
            String sel = (String) historyCardSelector.getSelectedItem();
            if (sel == null) { JOptionPane.showMessageDialog(this, "No card selected."); return; }
            int cid = Integer.parseInt(sel.split(" - ")[0].trim());
            String cardNo = sel.split(" - ").length > 1 ? sel.split(" - ")[1].split(" ")[0] : "N/A";
            List<Transaction> txns = txnSvc.getTransactionHistory(cid);
            historyModel.setRowCount(0);
            for (Transaction t : txns) {
                historyModel.addRow(new Object[]{
                    t.getTxnDate().toString().replace(".0", ""),
                    cardNo,
                    t.getTxnType(),
                    t.getAmount().toPlainString(),
                    t.getDescription()
                });
            }
            if (txns.isEmpty()) JOptionPane.showMessageDialog(this, "No transactions found for this card.");
        });

        return panel;
    }

    private int getSelectedCardId() {
        String sel = (String) txnCardSelector.getSelectedItem();
        if (sel == null) return -1;
        return Integer.parseInt(sel.split(" - ")[0].trim());
    }

    private void refreshData() {
        cardsPanel.removeAll();
        txnCardSelector.removeAllItems();
        if (historyCardSelector != null) historyCardSelector.removeAllItems();

        List<CreditCard> myCards = cardService.getCardsByUser(user.getUserId());
        for (CreditCard c : myCards) {
            String str = c.getCardId() + " - " + c.getCardNumber() + " [" + c.getStatus() + "]";
            txnCardSelector.addItem(str);
            if (historyCardSelector != null) historyCardSelector.addItem(str);

            // Styled card panel
            JPanel cp = new JPanel(new BorderLayout());
            cp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
            cp.setBackground(c.getStatus().equals("BLOCKED") ? new Color(231, 76, 60, 30) : Color.WHITE);
            cp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(6, 10, 6, 10),
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(c.getStatus().equals("BLOCKED") ? new Color(231, 76, 60) : new Color(41, 128, 185), 2, true),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)
                )
            ));
            JLabel cardTitle = new JLabel(c.getCardType() + " — " + c.getCardNumber());
            cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
            JLabel info = new JLabel("Limit: ₹" + c.getCreditLimit() + "  |  Balance: ₹" + c.getAvailableBalance()
                + "  |  Expiry: " + c.getExpiryDate() + "  |  Status: " + c.getStatus());
            info.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            info.setForeground(new Color(80, 80, 80));
            cp.add(cardTitle, BorderLayout.NORTH);
            cp.add(info, BorderLayout.CENTER);
            cardsPanel.add(cp);
        }

        cardsPanel.revalidate();
        cardsPanel.repaint();
    }
}
