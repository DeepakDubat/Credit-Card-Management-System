package ui.swing;

import models.User;
import services.UserService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class LoginFrame extends JFrame {

    private final UserService userService = new UserService();
    private static final Color DARK_BG    = new Color(20, 30, 48);
    private static final Color CARD_BG    = new Color(255, 255, 255);
    private static final Color ACCENT     = new Color(52, 152, 219);
    private static final Color ACCENT2    = new Color(39, 174, 96);
    private static final Color TEXT_DARK  = new Color(44, 62, 80);
    private static final Color TEXT_LIGHT = new Color(127, 140, 141);

    public LoginFrame() {
        setTitle("Credit Card Management — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 580);
        setLocationRelativeTo(null);
        setResizable(false);
        setUndecorated(false);

        // ── Root panel with dark blue gradient background ─────────
        JPanel root = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(20, 30, 48),
                                                      getWidth(), getHeight(), new Color(36, 59, 85));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };

        // ── Left branding panel ───────────────────────────────────
        JPanel leftPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(36, 59, 85),
                                                      0, getHeight(), new Color(20, 30, 48));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        leftPanel.setPreferredSize(new Dimension(360, 580));
        leftPanel.setOpaque(false);

        GridBagConstraints lGbc = new GridBagConstraints();
        lGbc.gridx = 0; lGbc.gridy = 0; lGbc.insets = new Insets(0, 0, 8, 0);

        // Credit card icon (drawn)
        JLabel iconLbl = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Card body
                GradientPaint gp = new GradientPaint(0, 0, ACCENT, 90, 60, new Color(142, 68, 173));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Double(0, 0, 90, 58, 12, 12));
                // Chip
                g2.setColor(new Color(241, 196, 15));
                g2.fill(new RoundRectangle2D.Double(10, 18, 22, 16, 4, 4));
                // Stripes
                g2.setColor(new Color(255, 255, 255, 60));
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(0, 42, 90, 42);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(90, 58); }
        };
        leftPanel.add(iconLbl, lGbc);

        lGbc.gridy = 1; lGbc.insets = new Insets(0, 0, 4, 0);
        JLabel brandLbl = new JLabel("CardVault");
        brandLbl.setFont(new Font("Segoe UI", Font.BOLD, 34));
        brandLbl.setForeground(Color.WHITE);
        leftPanel.add(brandLbl, lGbc);

        lGbc.gridy = 2; lGbc.insets = new Insets(0, 0, 30, 0);
        JLabel subLbl = new JLabel("Credit Card Management System");
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subLbl.setForeground(new Color(189, 195, 199));
        leftPanel.add(subLbl, lGbc);

        lGbc.gridy = 3; lGbc.insets = new Insets(0, 0, 10, 0);
        for (String feat : new String[]{"✔  Manage Credit Cards", "✔  Track Transactions", "✔  Generate Bills"}) {
            JLabel fl = new JLabel(feat);
            fl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            fl.setForeground(new Color(174, 214, 241));
            leftPanel.add(fl, lGbc);
            lGbc.gridy++;
        }

        root.add(leftPanel, BorderLayout.WEST);

        // ── Right card panel with tabs ────────────────────────────
        JPanel rightWrapper = new JPanel(new GridBagLayout());
        rightWrapper.setOpaque(false);

        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        card.setPreferredSize(new Dimension(440, 500));

        // Custom tab strip
        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabs.setBackground(CARD_BG);
        UIManager.put("TabbedPane.selected", CARD_BG);
        tabs.addTab("  Login  ", buildLoginPanel());
        tabs.addTab("  Register  ", buildRegisterPanel());
        card.add(tabs, BorderLayout.CENTER);

        rightWrapper.add(card);
        root.add(rightWrapper, BorderLayout.CENTER);

        setContentPane(root);
    }

    // ── Login panel ───────────────────────────────────────────────
    private JPanel buildLoginPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(CARD_BG);
        outer.setBorder(new EmptyBorder(30, 40, 30, 40));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(6, 0, 6, 0);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 1;

        JLabel welcome = new JLabel("Welcome back!");
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcome.setForeground(TEXT_DARK);
        outer.add(welcome, g);

        g.gridy++;
        JLabel sub = new JLabel("Sign in to your account");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_LIGHT);
        outer.add(sub, g);

        g.gridy++; g.insets = new Insets(18, 0, 4, 0);
        outer.add(fieldLabel("Username"), g);

        g.gridy++; g.insets = new Insets(0, 0, 6, 0);
        JTextField userF = styledField("Enter your username");
        outer.add(userF, g);

        g.gridy++; g.insets = new Insets(6, 0, 4, 0);
        outer.add(fieldLabel("Password"), g);

        g.gridy++; g.insets = new Insets(0, 0, 20, 0);
        JPasswordField passF = styledPassField("Enter your password");
        outer.add(passF, g);

        g.gridy++; g.insets = new Insets(0, 0, 0, 0);
        JButton loginBtn = bigButton("Sign In", ACCENT);
        loginBtn.addActionListener(e -> {
            String u = userF.getText().trim();
            String p = new String(passF.getPassword()).trim();
            if (u.isEmpty() || p.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter username and password.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            User user = userService.loginUser(u, p);
            if (user != null) {
                dispose();
                if ("ADMIN".equalsIgnoreCase(user.getRole()))
                    new AdminDashboardFrame(user).setVisible(true);
                else
                    new CustomerDashboardFrame(user).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials or account is inactive.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        });
        outer.add(loginBtn, g);

        // Enter key triggers login
        passF.addActionListener(e -> loginBtn.doClick());

        return outer;
    }

    // ── Register panel ────────────────────────────────────────────
    private JPanel buildRegisterPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(CARD_BG);
        outer.setBorder(new EmptyBorder(24, 40, 24, 40));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(4, 0, 4, 0);
        g.gridx = 0; g.gridy = 0;

        JLabel title = new JLabel("Create an account");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        outer.add(title, g);

        g.gridy++; g.insets = new Insets(2, 0, 14, 0);
        JLabel sub = new JLabel("Fill in your details to get started");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_LIGHT);
        outer.add(sub, g);

        String[] labels  = {"Username", "Password", "Email", "Phone Number"};
        JComponent[] flds = new JComponent[4];
        g.insets = new Insets(4, 0, 4, 0);
        for (int i = 0; i < labels.length; i++) {
            g.gridy++;
            outer.add(fieldLabel(labels[i]), g);
            g.gridy++;
            if (i == 1) {
                flds[i] = styledPassField("Min 6 characters");
            } else {
                flds[i] = styledField("");
            }
            outer.add(flds[i], g);
        }

        g.gridy++; g.insets = new Insets(16, 0, 0, 0);
        JButton regBtn = bigButton("Create Account", ACCENT2);
        regBtn.addActionListener(e -> {
            String u  = ((JTextField) flds[0]).getText().trim();
            String p  = new String(((JPasswordField) flds[1]).getPassword()).trim();
            String em = ((JTextField) flds[2]).getText().trim();
            String ph = ((JTextField) flds[3]).getText().trim();
            if (u.isEmpty() || p.isEmpty() || em.isEmpty() || ph.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String res = userService.registerUser(u, p, em, ph);
            if (res.startsWith("SUCCESS")) {
                JOptionPane.showMessageDialog(this, "Account created! You can now sign in.", "Success", JOptionPane.INFORMATION_MESSAGE);
                for (JComponent c : flds) {
                    if (c instanceof JTextField) ((JTextField) c).setText("");
                    if (c instanceof JPasswordField) ((JPasswordField) c).setText("");
                }
            } else {
                JOptionPane.showMessageDialog(this, res.replace("ERROR: ", ""), "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        outer.add(regBtn, g);
        return outer;
    }

    // ── Shared UI helpers ─────────────────────────────────────────
    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(TEXT_DARK);
        return l;
    }

    private JTextField styledField(String placeholder) {
        JTextField f = new JTextField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1, true),
            new EmptyBorder(8, 12, 8, 12)));
        f.setPreferredSize(new Dimension(0, 42));
        if (!placeholder.isEmpty()) {
            f.setForeground(TEXT_LIGHT);
            f.setText(placeholder);
            f.addFocusListener(new FocusAdapter() {
                public void focusGained(FocusEvent e) {
                    if (f.getText().equals(placeholder)) { f.setText(""); f.setForeground(TEXT_DARK); }
                }
                public void focusLost(FocusEvent e) {
                    if (f.getText().isEmpty()) { f.setText(placeholder); f.setForeground(TEXT_LIGHT); }
                }
            });
        }
        return f;
    }

    private JPasswordField styledPassField(String hint) {
        JPasswordField f = new JPasswordField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1, true),
            new EmptyBorder(8, 12, 8, 12)));
        f.setPreferredSize(new Dimension(0, 42));
        return f;
    }

    private JButton bigButton(String text, Color bg) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? bg.darker() :
                            getModel().isRollover() ? bg.brighter() : bg);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                              (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        b.setFont(new Font("Segoe UI", Font.BOLD, 15));
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(0, 46));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
}
