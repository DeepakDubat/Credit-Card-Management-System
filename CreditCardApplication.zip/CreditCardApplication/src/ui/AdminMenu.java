package ui;

import models.CreditCard;
import models.User;
import services.*;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {

    private final Scanner sc;
    private final User admin;
    private final UserService       userService  = new UserService();
    private final CardService       cardService  = new CardService();
    private final ReportService     reportService = new ReportService();
    private final BillingService    billingService = new BillingService();
    private final TransactionService txnService  = new TransactionService();

    public AdminMenu(Scanner sc, User admin) {
        this.sc    = sc;
        this.admin = admin;
    }

    public void show() {
        boolean running = true;
        while (running) {
            System.out.println("\n  ┌──────────────────────────────────────┐");
            System.out.println("  │          ADMIN MENU                  │");
            System.out.println("  ├──────────────────────────────────────┤");
            System.out.println("  │  1.  Admin Dashboard                 │");
            System.out.println("  │  2.  View All Users                  │");
            System.out.println("  │  3.  Delete / Deactivate User        │");
            System.out.println("  │  4.  View All Cards                  │");
            System.out.println("  │  5.  Pending Card Approvals          │");
            System.out.println("  │  6.  Issue (Approve) Card            │");
            System.out.println("  │  7.  Block a Card                    │");
            System.out.println("  │  8.  Unblock a Card                  │");
            System.out.println("  │  9.  Update Credit Limit             │");
            System.out.println("  │  10. Generate Bill for a Card        │");
            System.out.println("  │  11. View All Unpaid Bills           │");
            System.out.println("  │  12. View All Transactions           │");
            System.out.println("  │  0.  Logout                          │");
            System.out.println("  └──────────────────────────────────────┘");

            switch (Main.readInt("Choose option: ")) {
                case 1  -> reportService.adminDashboard();
                case 2  -> viewAllUsers();
                case 3  -> deactivateUser();
                case 4  -> viewAllCards();
                case 5  -> viewPendingCards();
                case 6  -> issueCard();
                case 7  -> blockCard();
                case 8  -> unblockCard();
                case 9  -> updateCreditLimit();
                case 10 -> generateBill();
                case 11 -> viewUnpaidBills();
                case 12 -> viewAllTransactions();
                case 0  -> { System.out.println("\n  [✓] Logged out successfully."); running = false; }
                default -> System.out.println("  [!] Invalid option.");
            }
        }
    }

    // ── 2. View All Users ────────────────────────────────────────
    private void viewAllUsers() {
        List<User> users = userService.getAllUsers();
        System.out.println("\n  ── ALL USERS (" + users.size() + " found) ──────────────────────");
        for (User u : users) System.out.println(u);
    }

    // ── 3. Deactivate User ───────────────────────────────────────
    private void deactivateUser() {
        int userId = Main.readInt("Enter User ID to deactivate: ");
        System.out.print("  Type 'CONFIRM' to proceed: ");
        String confirm = sc.nextLine().trim();
        if ("CONFIRM".equalsIgnoreCase(confirm)) {
            System.out.println("  " + userService.deleteAccount(userId));
        } else {
            System.out.println("  [!] Cancelled.");
        }
    }

    // ── 4. View All Cards ────────────────────────────────────────
    private void viewAllCards() {
        List<CreditCard> cards = cardService.getAllCards();
        System.out.println("\n  ── ALL CARDS (" + cards.size() + " found) ──────────────────────");
        for (CreditCard c : cards) System.out.println(c);
    }

    // ── 5. View Pending Cards ────────────────────────────────────
    private void viewPendingCards() {
        List<CreditCard> cards = cardService.getPendingCards();
        if (cards.isEmpty()) {
            System.out.println("  No pending card applications.");
            return;
        }
        System.out.println("\n  ── PENDING CARD APPLICATIONS (" + cards.size() + ") ──────────");
        for (CreditCard c : cards) System.out.println(c);
    }

    // ── 6. Issue Card ────────────────────────────────────────────
    private void issueCard() {
        viewPendingCards();
        int cardId = Main.readInt("Enter Card ID to approve: ");
        System.out.println("  " + cardService.issueCard(cardId));
    }

    // ── 7. Block Card ────────────────────────────────────────────
    private void blockCard() {
        int cardId = Main.readInt("Enter Card ID to block: ");
        System.out.println("  " + cardService.blockCard(cardId));
    }

    // ── 8. Unblock Card ──────────────────────────────────────────
    private void unblockCard() {
        int cardId = Main.readInt("Enter Card ID to unblock: ");
        System.out.println("  " + cardService.unblockCard(cardId));
    }

    // ── 9. Update Credit Limit ───────────────────────────────────
    private void updateCreditLimit() {
        int    cardId   = Main.readInt("Enter Card ID: ");
        double newLimit = Main.readDouble("Enter new credit limit (₹): ");
        System.out.println("  " + cardService.updateCreditLimit(cardId, newLimit));
    }

    // ── 10. Generate Bill ────────────────────────────────────────
    private void generateBill() {
        int    cardId    = Main.readInt("Enter Card ID: ");
        System.out.print("  Enter bill month (YYYY-MM): ");
        String month = sc.nextLine().trim();
        System.out.println("  " + billingService.generateBill(cardId, month));
    }

    // ── 11. View Unpaid Bills ────────────────────────────────────
    private void viewUnpaidBills() {
        var bills = billingService.getAllUnpaidBills();
        System.out.println("\n  ── UNPAID BILLS (" + bills.size() + ") ─────────────────────────");
        for (var b : bills) System.out.println(b);
    }

    // ── 12. View All Transactions ────────────────────────────────
    private void viewAllTransactions() {
        var txns = txnService.getAllTransactions();
        System.out.println("\n  ── RECENT TRANSACTIONS (last 100) ─────────────────");
        for (var t : txns) System.out.println(t);
    }
}
