package ui;

import models.CreditCard;
import models.User;
import services.*;
import java.util.List;
import java.util.Scanner;

public class CustomerMenu {

    private final Scanner sc;
    private final User customer;
    private final CardService        cardService    = new CardService();
    private final TransactionService txnService     = new TransactionService();
    private final BillingService     billingService = new BillingService();
    private final SecurityService    secService     = new SecurityService();
    private final ReportService      reportService  = new ReportService();
    private final UserService        userService    = new UserService();

    public CustomerMenu(Scanner sc, User customer) {
        this.sc       = sc;
        this.customer = customer;
    }

    public void show() {
        boolean running = true;
        while (running) {
            System.out.println("\n  ┌──────────────────────────────────────┐");
            System.out.println("  │       CUSTOMER MENU                  │");
            System.out.printf ("  │       Hello, %-22s│%n", customer.getUserName() + "!");
            System.out.println("  ├──────────────────────────────────────┤");
            System.out.println("  │  1.  My Cards                        │");
            System.out.println("  │  2.  Apply for New Card              │");
            System.out.println("  │  3.  Check Card Balance              │");
            System.out.println("  │  4.  Make a Purchase                 │");
            System.out.println("  │  5.  Cash Advance                    │");
            System.out.println("  │  6.  View Transaction History        │");
            System.out.println("  │  7.  View Bill Statement             │");
            System.out.println("  │  8.  Pay Bill                        │");
            System.out.println("  │  9.  Convert Bill to EMI             │");
            System.out.println("  │  10. Set / Change Card PIN           │");
            System.out.println("  │  11. Lock My Card (Security)         │");
            System.out.println("  │  12. Unlock My Card (via OTP)        │");
            System.out.println("  │  13. Monthly Spending Summary        │");
            System.out.println("  │  14. Spending Analysis               │");
            System.out.println("  │  15. Update My Profile               │");
            System.out.println("  │  16. Change Password                 │");
            System.out.println("  │  0.  Logout                          │");
            System.out.println("  └──────────────────────────────────────┘");

            switch (Main.readInt("Choose option: ")) {
                case 1  -> viewMyCards();
                case 2  -> applyCard();
                case 3  -> checkBalance();
                case 4  -> makePurchase();
                case 5  -> cashAdvance();
                case 6  -> viewTransactionHistory();
                case 7  -> viewStatement();
                case 8  -> payBill();
                case 9  -> convertEMI();
                case 10 -> setPin();
                case 11 -> lockCard();
                case 12 -> unlockCard();
                case 13 -> monthlySummary();
                case 14 -> spendingAnalysis();
                case 15 -> updateProfile();
                case 16 -> changePassword();
                case 0  -> { System.out.println("\n  [✓] Logged out successfully."); running = false; }
                default -> System.out.println("  [!] Invalid option.");
            }
        }
    }

    // ── Helper: pick one of user's cards ────────────────────────
    private int pickCardId() {
        List<CreditCard> cards = cardService.getCardsByUser(customer.getUserId());
        if (cards.isEmpty()) {
            System.out.println("  You have no cards. Apply for one first.");
            return -1;
        }
        System.out.println("\n  Your cards:");
        for (CreditCard c : cards) System.out.println(c);
        return Main.readInt("Enter Card ID: ");
    }

    // ── 1. My Cards ──────────────────────────────────────────────
    private void viewMyCards() {
        List<CreditCard> cards = cardService.getCardsByUser(customer.getUserId());
        if (cards.isEmpty()) { System.out.println("  You have no cards yet."); return; }
        System.out.println("\n  ── YOUR CARDS ──────────────────────────────");
        for (CreditCard c : cards) System.out.println(c);
    }

    // ── 2. Apply for Card ────────────────────────────────────────
    private void applyCard() {
        System.out.println("  Card types: VISA / MASTERCARD / RUPAY");
        System.out.print("  Select card type (default: VISA): ");
        String type = sc.nextLine().trim();
        if (type.isEmpty()) type = "VISA";
        System.out.println("  " + cardService.applyForCard(customer.getUserId(), type));
    }

    // ── 3. Check Balance ─────────────────────────────────────────
    private void checkBalance() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        System.out.println(cardService.checkBalance(cardId));
    }

    // ── 4. Make Purchase ─────────────────────────────────────────
    private void makePurchase() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        double amount = Main.readDouble("  Enter purchase amount (₹): ");
        System.out.print("  Description (optional): ");
        String desc = sc.nextLine().trim();
        System.out.println("  " + txnService.makePurchase(cardId, amount, desc));
    }

    // ── 5. Cash Advance ──────────────────────────────────────────
    private void cashAdvance() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        double amount = Main.readDouble("  Enter cash advance amount (₹): ");
        System.out.println("  " + txnService.cashAdvance(cardId, amount));
    }

    // ── 6. Transaction History ───────────────────────────────────
    private void viewTransactionHistory() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        var txns = txnService.getTransactionHistory(cardId);
        System.out.println("\n  ── TRANSACTION HISTORY ─────────────────────");
        if (txns.isEmpty()) System.out.println("  No transactions found.");
        else txns.forEach(System.out::println);
    }

    // ── 7. View Statement ────────────────────────────────────────
    private void viewStatement() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        var bills = billingService.getStatement(cardId);
        System.out.println("\n  ── BILLING STATEMENT ───────────────────────");
        if (bills.isEmpty()) System.out.println("  No bills found.");
        else bills.forEach(System.out::println);
    }

    // ── 8. Pay Bill ──────────────────────────────────────────────
    private void payBill() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        viewStatement();
        int    billId  = Main.readInt("Enter Bill ID to pay: ");
        double amount  = Main.readDouble("Enter payment amount (₹): ");
        System.out.println("  " + billingService.makePayment(billId, amount, cardId));
    }

    // ── 9. Convert to EMI ────────────────────────────────────────
    private void convertEMI() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        viewStatement();
        int billId = Main.readInt("Enter Bill ID to convert: ");
        int months = Main.readInt("Enter EMI tenure (2-24 months): ");
        System.out.println("  " + billingService.convertToEMI(billId, months));
    }

    // ── 10. Set PIN ──────────────────────────────────────────────
    private void setPin() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        System.out.print("  Enter new 4-digit PIN: ");
        String pin = sc.nextLine().trim();
        System.out.println("  " + secService.setPIN(cardId, pin));
    }

    // ── 11. Lock Card ────────────────────────────────────────────
    private void lockCard() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        System.out.println("  " + secService.lockCard(cardId));
    }

    // ── 12. Unlock Card ──────────────────────────────────────────
    private void unlockCard() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        // Send OTP to registered phone
        secService.generateOTP(customer.getPhoneNo());
        System.out.print("  Enter OTP: ");
        String otp = sc.nextLine().trim();
        System.out.println("  " + secService.unlockCard(cardId, otp));
    }

    // ── 13. Monthly Summary ──────────────────────────────────────
    private void monthlySummary() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        System.out.print("  Enter month (YYYY-MM): ");
        String month = sc.nextLine().trim();
        reportService.monthlySummary(cardId, month);
    }

    // ── 14. Spending Analysis ────────────────────────────────────
    private void spendingAnalysis() {
        int cardId = pickCardId();
        if (cardId < 0) return;
        reportService.spendingAnalysis(cardId);
    }

    // ── 15. Update Profile ───────────────────────────────────────
    private void updateProfile() {
        System.out.print("  New Email   : "); String email = sc.nextLine().trim();
        System.out.print("  New Phone   : "); String phone = sc.nextLine().trim();
        System.out.println("  " + userService.updateProfile(customer.getUserId(), email, phone));
    }

    // ── 16. Change Password ──────────────────────────────────────
    private void changePassword() {
        System.out.print("  Current Password : "); String oldPass = sc.nextLine().trim();
        System.out.print("  New Password     : "); String newPass = sc.nextLine().trim();
        System.out.println("  " + userService.changePassword(customer.getUserId(), oldPass, newPass));
    }
}
