package ui;

import dao.DBConnection;
import models.User;
import services.UserService;
import java.util.Scanner;

/**
 * Main.java — Entry point of the Credit Card Management System.
 * Handles login, registration, and routing to Admin/Customer menus.
 */
public class Main {

    static Scanner sc = new Scanner(System.in);
    static UserService userService = new UserService();
    static User loggedInUser = null;

    public static void main(String[] args) {
        printBanner();
        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1 -> login();
                case 2 -> register();
                case 3 -> { running = false; exit(); }
                default -> System.out.println("  [!] Invalid choice. Try again.");
            }
        }
    }

    // ── Login ────────────────────────────────────────────────────
    private static void login() {
        System.out.println("\n  ─── LOGIN ────────────────────────────────");
        System.out.print("  Username : "); String username = sc.nextLine().trim();
        System.out.print("  Password : "); String password = sc.nextLine().trim();

        loggedInUser = userService.loginUser(username, password);
        if (loggedInUser == null) {
            System.out.println("\n  [✗] Invalid credentials or account inactive.\n");
            return;
        }

        System.out.println("\n  [✓] Welcome, " + loggedInUser.getUserName() +
                           "! Role: " + loggedInUser.getRole());

        if ("ADMIN".equals(loggedInUser.getRole())) {
            new AdminMenu(sc, loggedInUser).show();
        } else {
            new CustomerMenu(sc, loggedInUser).show();
        }
        loggedInUser = null;
    }

    // ── Register ─────────────────────────────────────────────────
    private static void register() {
        System.out.println("\n  ─── REGISTER ─────────────────────────────");
        System.out.print("  Full Username (min 4 chars) : "); String username = sc.nextLine().trim();
        System.out.print("  Password (min 6 chars)      : "); String password = sc.nextLine().trim();
        System.out.print("  Email                       : "); String email    = sc.nextLine().trim();
        System.out.print("  Phone Number                : "); String phone    = sc.nextLine().trim();

        String result = userService.registerUser(username, password, email, phone);
        System.out.println("\n  " + result + "\n");
    }

    // ── Exit ─────────────────────────────────────────────────────
    private static void exit() {
        DBConnection.closeConnection();
        System.out.println("\n  Thank you for using Credit Card Management System!");
        System.out.println("  Goodbye!\n");
    }

    // ── UI Helpers ───────────────────────────────────────────────
    private static void printBanner() {
        System.out.println("\n  ╔══════════════════════════════════════════════╗");
        System.out.println("  ║    CREDIT CARD MANAGEMENT SYSTEM v1.0        ║");
        System.out.println("  ║    Powered by Java + MySQL                   ║");
        System.out.println("  ╚══════════════════════════════════════════════╝");
    }

    private static void printMainMenu() {
        System.out.println("\n  ┌─────────────────────────────────┐");
        System.out.println("  │          MAIN MENU              │");
        System.out.println("  ├─────────────────────────────────┤");
        System.out.println("  │  1. Login                       │");
        System.out.println("  │  2. Register                    │");
        System.out.println("  │  3. Exit                        │");
        System.out.println("  └─────────────────────────────────┘");
    }

    // ── Read integer safely ──────────────────────────────────────
    public static int readInt(String prompt) {
        while (true) {
            System.out.print("  " + prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  [!] Please enter a valid number.");
            }
        }
    }

    // ── Read double safely ───────────────────────────────────────
    public static double readDouble(String prompt) {
        while (true) {
            System.out.print("  " + prompt);
            try {
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  [!] Please enter a valid amount.");
            }
        }
    }
}
